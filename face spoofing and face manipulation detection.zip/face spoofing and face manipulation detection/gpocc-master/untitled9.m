%clear
clear K1
clear Ktest
clear Ktest2
clear Ktest1
Faceforensics={'Face2Face','Deepfakes','FaceShifter','FaceSwap','NeuralTextures'};
Model={'alexnet','darknet19','inceptionv3'};
region={'R1','R2','R3'};
count=1;
for f=5
Faces=Faceforensics{1,f};
for r=1:3
 R=region{1,r};   
for net=1:3

Network=Model{1,net};
matfiles_real = (dir(fullfile('E:\original\freq\',R,'\',Network,'\Real\*.mat'))); 
matfiles_fake = (dir(fullfile('E:\',Faces,'\freq\',R,'\',Network,'\',Faces,'\*.mat'))) ;
N = length(matfiles_real) 
path =fullfile('E:\original\freq\',R,'\',Network,'\Real\');
path1 =fullfile('E:\',Faces,'\freq\',R,'\',Network,'\',Faces,'\');
%%%googlenet KPCA

data_real=cell(N,1);
data_fake=cell(N,1);
for jj=2


clear K1
clear Ktest
clear Ktest2
clear Ktest1
if f==2||3||4   
file=matfiles_real(jj).name;
currentfile=[path,file]; 
file1=matfiles_fake(jj).name;
fname=file1(5:7);
d=str2num(file1(5:7));
file1=matfiles_fake(d+1).name;
currentfile1=[path1,file1];
S = load(currentfile1);
S1 = load(currentfile);

else
file1=matfiles_fake(jj).name;
currentfile1=[path1,file1];   
file=matfiles_real(jj).name;
currentfile=[path,file]; 
S = load(currentfile1);
S1 = load(currentfile);
end


data=cell2mat(struct2cell(S1))';
data1=cell2mat(struct2cell(S))';

if net==5
    data=zscore(cell2mat(struct2cell(S1))');
    data1=zscore(cell2mat(struct2cell(S))');
end

x_real=normr(data);
x_fake=normr(data1);

[m_real,n_real]=size(x_real);
[m_fake,n_fake]=size(x_fake);

m_train=round(m_real*0.72);
m_train_fake=round(m_fake*0.72);
m_vali_test_real=round(m_real*0.14);
m_vali_test_fake=round(m_fake*0.14);

x_train=x_real(1:m_train,:);
x_vali_real=x_real(m_train+1:m_train+m_vali_test_real,:);
x_test_real=x_real(m_train+m_vali_test_real+1:m_real,:);

x_vali_fake=x_fake(m_train_fake+1:m_train_fake+m_vali_test_fake,:);
x_test_fake=x_fake(m_train_fake+m_vali_test_fake+1:m_fake,:);

x_vali=[x_vali_real;x_vali_fake];
x_test=[x_test_real;x_test_fake];

%%%%%KPCA
coeff=0.25;
G = EuDist2(x_train,x_train,0);
D = sum(sum(triu(G,1)));
Md1 = coeff*D/(size(G,1)-1)/(size(G,1)-2);
K1= exp(-1*G./Md1);
T=reshape(1/12*sum(K1,1),size(K1,2),size(K1,3));
clear kz14
clear G
G = EuDist2(x_train,x_vali_real,0);
kz14 = exp(-1*G./Md1);
Ktest = reshape(1/12*sum(kz14,1),size(kz14,2),size(kz14,3));
clear kz141
clear G
G = EuDist2(x_train,x_vali_fake,0);
kz141= exp(-1*G./Md1);
Ktest2 = reshape(1/12*sum(kz141,1),size(kz141,2),size(kz141,3));
clear kz12
clear G
G = EuDist2(x_train,x_test,0);
kz12= exp(-1*G./Md1);
Ktest1 = reshape(1/12*sum(kz12,1),size(kz12,2),size(kz12,3));
% 
T=reshape(1/12*sum(K1,1),size(K1,2),size(K1,3));
N=size(T,1)
k=10;
fprintf('Dimension of Projection Space: %d ',k);
KPCA=T*T';
KPCA_=KPCA - (2/N)*ones(N,N)*KPCA + ((1/N)*ones(N,N))*KPCA*((1/N)*ones(N,N));
[V,D]=eig(KPCA_);
alpha=V(:,1:k);
lam=diag(D);
for j=1:k
    alpha(:,j)=(alpha(:,j)/norm(alpha(:,j)))/sqrt(lam(j));
end
xKpca=(alpha'*KPCA_)';

Y=K1'*xKpca;
RTscore_train=2/size(K1,2)*sum(K1,1)'-sum((Y.^2),2);


Y=kz14'*xKpca;
RTscore_vali=2/size(K1,2)*sum(kz14,1)'-sum((Y.^2),2);

Y=kz141'*xKpca;
ATscore_vali=2/size(K1,2)*sum(kz141,1)'-sum((Y.^2),2);

Y=kz12'*xKpca;
ATscore_test=2/size(K1,2)*sum(kz12,1)'-sum((Y.^2),2);
file_name = [num2str(jj)]
% kpca = KernelPca(x_train, 'gaussian', 'gamma', 2.5, 'AutoScale', true);
% 
% M = 2;
% 
% projected_X = project(kpca, x_train, M);
% 
% projected_Xtest = project(kpca, x_test, M);
% 
% ATscores=-2/size(x_train',2)*sum(x_test',1)'-sum((projected_Xtest.^2),2);
% % % 
fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\KPCA\RTscores\train\', file_name);
save(strcat(fullFileName_attack,'.mat'),'RTscore_train');

fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\KPCA\RTscores\vali\', file_name);
save(strcat(fullFileName_attack,'.mat'),'RTscore_vali');

fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\KPCA\ATscores\vali\', file_name);
save(strcat(fullFileName_attack,'.mat'),'ATscore_vali');

fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\KPCA\ATscores\test\', file_name);
save(strcat(fullFileName_attack,'.mat'),'ATscore_test');

% % %%%%%KPCA
% % %%%%%SVDD_STARTS
[m1,n1]=size(x_train);
[m2,n2]=size(x_test_real);
[m3,n3]=size(x_test_fake);
[m4,n4]=size(x_vali_real);
[m5,n5]=size(x_vali_fake);

trainLabel=ones(m1,1);
valiLabel=ones(m4,1);
valiLabel2=-1*ones(m5,1);
valiLabel0=[valiLabel;valiLabel2];
testLabel=[ones(m2,1);zeros(m3,1)];
[~,~,T11,AUCf_attack] = perfcurve(testLabel,ATscore_test,1);
[~,~,T11,AUCf_attack_kpca] = perfcurve(testLabel,ATscore_test,1);
% fullFileName_attack = fullfile('E:\scores\',Faces,'\label\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'testLabel');
% % creat an SVDD object
% cost = 0.9;
% gamma=5;
% % % for g=1
% % % kernel = BaseKernel('type', 'gaussian', 'gamma', gamma);
% % % svddParameter = struct('cost', cost, 'kernelFunc', kernel);
% % % svdd = BaseSVDD(svddParameter);
% % % % train SVDD model
% % % svdd.train(x_train, trainLabel);
% % % results_vali = svdd.test(x_vali, valiLabel0);
% % % accuracy(g,1)=results_vali.performance.AUC;
% % % gg(g,1)=gamma;
% % % if results_vali.performance.AUC>=0.90
% % %         maximum = max(max(accuracy));
% % %         [x,y]=find(accuracy==maximum);
% % %         gamma1(jj,1)=gg(x(1,1),1);     
% % %     break
% % % else
% % %     gamma=gamma/2;
% % % end
% % % if g==10
% % %     if results_vali.performance.accuracy<0.90
% % %         maximum = max(max(accuracy));
% % %         [x,y]=find(accuracy==maximum);
% % %         gamma1(jj,1)=gg(x(1,1),1);        
% % %     end
% % % end
% % % end
% % % gamma=gamma1(jj,1);
% kernel = BaseKernel('type', 'gaussian', 'gamma', gamma);
% svddParameter = struct('cost', cost, 'kernelFunc', kernel);
% svdd = BaseSVDD(svddParameter);
% % train SVDD model
% svdd.train(x_train, trainLabel);
% % test SVDD model
% testLabel1=[ones(m2,1);-ones(m3,1)];
% results_train = svdd.test(x_train, trainLabel);
% results_vali = svdd.test(x_vali_real, valiLabel);
% results_vali2 = svdd.test(x_vali_fake, valiLabel2);
% results_test = svdd.test(x_test, testLabel1);
% 
% 
% 
% % compute the distance between each test sample and the center
% 
% RTscores=svdd.radius-results_train.distance;
% RTscore_train=RTscores;%mean(mean(svdd.supportVectors))*eye(size(results_train.predictedLabel,1),1)-results_train.predictedLabel;
% 
% 
% RTscores=svdd.radius-results_vali.distance;
% RTscore_vali=RTscores;%svdd.radius-results_test.predictedLabel;
% 
% 
% ATscores=svdd.radius-results_vali2.distance;
% ATscore_vali=ATscores;%results_vali2.predictedLabel;
% 
% 
% ATscores=svdd.radius-results_test.distance;
% ATscore_test=ATscores;%min(mean(svdd.supportVectors))*eye(size(results_test.predictedLabel,1),1)-results_test.predictedLabel;
% 
% [~,~,T11,AUCf_attack_svdd] = perfcurve(testLabel,ATscore_test,1);
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\SVDD\RTscores\train\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'RTscore_train');
% 
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\SVDD\RTscores\vali\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'RTscore_vali');
% 
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\SVDD\ATscores\vali\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'ATscore_vali');
% 
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\SVDD\ATscores\test\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'ATscore_test')
% %%%%SVDD_ENDS
% %%%%GPR_STARTS
% % meanfunc = @meanConst;
% % covfunc = @covRQiso; 
% % likfunc = @likGauss; 
% % 
% % % Initialization of hyperparameters
% % hyp = struct('mean', 3, 'cov', [0 0 0], 'lik', -1);
% % 
% % 
% % % meanfunc = [];
% % % covfunc = @covSEiso; 
% % % likfunc = @likGauss; 
% % % % Initialization of hyperparameters
% % % hyp = struct('mean', [], 'cov', [0 0], 'lik', -1);
% % 
% % 
% % % Optimization of hyperparameters
% % hyp2 = minimize(hyp, @gp, -20, @infGaussLik, meanfunc, covfunc, likfunc,x_train, trainLabel);
% % 
% % % Regression using GPR
% % % yfit is the predicted mean, and ys is the predicted variance
% % [yfit RTscore_train] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc,x_train, trainLabel, x_train);
% % [yfit RTscore_vali] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc,x_train, trainLabel, x_vali_real);
% % [yfit ATscore_vali] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc,x_train, trainLabel, x_vali_fake);
% % [yfit ATscore_test] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc,x_train, trainLabel, x_test);
% k=2;
% coeff=.25;
% G = EuDist2(x_train,x_train,0);
% D = sum(sum(triu(G,1)));
% Md1 = coeff*D/(size(G,1)-1)/(size(G,1)-2);
% K1 = exp(-1*G./Md1);
% T=reshape(1/12*sum(K1,1),size(K1,2),size(K1,3));
% clear kz14
% G = EuDist2(x_train,x_test,0);
% kz14= exp(-1*G./Md1);
% Ks= reshape(1/12*sum(kz14,1),size(kz14,2),size(kz14,3));
% clear kz15
% G = EuDist2(x_train,1,0);
% kz15= exp(-1*G./Md1);
% Kss = reshape(1/12*sum(kz15,1),size(kz15,2),size(kz15,3));
% clear kz15
% G = EuDist2(x_test,1,0);
% kz15= exp(-1*G./Md1);
% Kss1 = reshape(1/12*sum(kz15,1),size(kz15,2),size(kz15,3));
% clear kz15
% G = EuDist2(x_vali_fake,1,0);
% kz15= exp(-1*G./Md1);
% Kss2 = reshape(1/12*sum(kz15,1),size(kz15,2),size(kz15,3));
% clear kz15
% G = EuDist2(x_vali_real,1,0);
% kz15= exp(-1*G./Md1);
% Kss3 = reshape(1/12*sum(kz15,1),size(kz15,2),size(kz15,3));
% 
% modes={'mean','var','pred','ratio'};
% titles={'mean \mu_*','neg. variance -\sigma^2_*','log. predictive probability p(y=1|X,y,x_*)','log. moment ratio \mu_*/\sigma_*'};
% score=GPR_OCC(K1,K1,Kss,modes{1});
% RTscore_train=score;
% score=GPR_OCC(K1,kz12,Kss1,modes{1});
% ATscore_test=score;
% score=GPR_OCC(K1,kz141,Kss2,modes{1});
% ATscore_vali=score;
% score=GPR_OCC(K1,kz14,Kss3,modes{1});
% RTscore_vali=score;
% 
% [~,~,T11,AUCf_attack_gpr] = perfcurve(testLabel,ATscore_test,1);
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\GPR\RTscores\train\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'RTscore_train');
% 
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\GPR\RTscores\vali\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'RTscore_vali');
% 
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\GPR\ATscores\vali\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'ATscore_vali');
% 
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\GPR\ATscores\test\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'ATscore_test');
% %%%%%GPR_ENDS
% %%%%%GMM_STARTS
% % number=3;
% % [mt,nt]=size(x_train);
% % if mt<nt
% %     data123=x_train';
% %     data123_train=T';
% %     data123_vali_fake=Ktest';
% %     data123_vali_real=Ktest2';
% %     data123_test=Ktest1';
% % % else
% % %     data123=x_train;
% % %     data123_train=T;
% % %     data123_vali_fake=Ktest;
% % %     data123_vali_real=Ktest2;
% % %     data123_test=Ktest1;
% % end
% % model= gmdistribution.fit(data123,number,'Regularize',.1);
% % 
% % Pos_train=  posterior(model,data123_train);
% % Pos_vali=  posterior(model,data123_vali_fake);
% % Pos_vali2=  posterior(model,data123_vali_real);
% % Pos_test=  posterior(model,data123_test);
% % 
% % RTscore_train=mahal(Pos_train,Pos_train);
% % RTscore_vali=mahal(Pos_vali,Pos_train);
% % ATscore_vali=mahal(Pos_vali2,Pos_train);
% % ATscore_test=mahal(Pos_test,Pos_train);
% % clear x3
% clear x2
% clear x1
% xxtrain=x_train;
% [mx,nx]=size(xxtrain);
% if mx<=nx 
% X=x_train(:,1:m1-1);
% y=ones(mx,1);
% X1_1=x_test_fake(:,1:m1-1);
% X1_2=x_test_real(:,1:m1-1);
% X2=x_vali_real(:,1:m1-1);
% X3=x_vali_fake(:,1:m1-1);
% else
% X=x_train;
% y=ones(mx,1);
% X1_1=x_test_fake;
% X1_2=x_test_real;
% X2=x_vali_real;
% X3=x_vali_fake;
% end
% % 
% [m1,n1]=size(X);
% [m1_1,n1_1]=size(X1_1);
% [m1_2,n1_2]=size(X1_2);
% [m3,n3]=size(X2);
% [m4,n4]=size(X3);
% gmm=fitgmdist(X,3,"RegularizationValue",.1);
% if m1>m1_1|| m1>m4
% X=X;
% x1_1=cat(1,X1_1,zeros(m1-m1_1,size(X,2)));
% x1_2=cat(1,X1_2,zeros(m1-m1_2,size(X,2)));
% x2=cat(1,X2,zeros(m1-m3,size(X,2)));
% x3=cat(1,X3,zeros(m1-m4,size(X,2)));
% else
%     if m1_1>=m4
%         X=cat(1,X,zeros(m1_1-m1,size(X,2)));   
%         x1_1=X1_1;
%         x1_2=cat(1,X1_2,zeros(m1_1-m1_2,size(X,2)));
%         x2=cat(1,X2,zeros(m1_1-m3,size(X,2)));
%         x3=cat(1,X3,zeros(m1_1-m4,size(X,2)));
%     else
%         X=cat(1,X,zeros(m4-m1,size(X,2)));   
%         x1_1=cat(1,X1_1,zeros(m4-m1_1,size(X,2)));
%         x1_2=cat(1,X1_2,zeros(m4-m1_2,size(X,2)));
%         x2=cat(1,X2,zeros(m4-m3,size(X,2)));
%         x3=X3;
%     end
% 
% end
% % Load data and initialize variables
% 
% X = X; % input data
% 
% mu=gmm.mu; % mean vectors
% Sigma = gmm.Sigma; % covariance matrices
% % Load data and initialize variables
% 
% 
% K = size(mu,1); % number of mixture components
% N = size(X,1);
% 
% % Preallocate memory
% w = zeros(N,K);
% 
% % Loop through mixture components
% for k = 1:K
%     % Evaluate GMM PDF at each data point
%     w(:,k) = mvnpdf(X, mu(k,:), Sigma(:,:,k));
% end
% % Normalize weights
% w = bsxfun(@rdivide, w, sum(w,2));
% clear scores
% scores = zeros(N,K);
% weights = gmm.ComponentProportion;
% for k = 1:K
%     weight=weights(:,k);
%     diff = bsxfun(@minus, X, mu(k,:));
%     distance = sqrt(sum((diff / Sigma(:,:,k)) .* diff, 2));
%     scores(:,k) = scores(k) + weight * distance;
% end
% 
% [mm,nn]=find(min(mean(scores(1:m1,:),2)));
% 
% RTscore_train=scores(1:m1,nn);  
% 
% %%%%%%%%%%test
% clear scores
% scores = zeros(N,K);
% weights = gmm.ComponentProportion;
% for k = 1:K
%     weight=weights(:,k);
%     diff = bsxfun(@minus, x1_1, mu(k,:));
%     distance= sqrt(sum((diff / Sigma(:,:,k)) .* diff, 2));
%     scores(:,k) = scores(k) + weight * distance;
% end
% %Pos_test2=  posterior(gmm,x1_1);
% [mm,nn]=find(min(mean(scores(1:m3,:))));
% ATscore_test=scores(1:m1_1,nn);
% 
% 
% %%%%%%%%
% clear scores
% scores = zeros(N,K);
% weights = gmm.ComponentProportion;
% for k = 1:K
%     weight=weights(:,k);
%     diff = bsxfun(@minus, x1_2, mu(k,:));
%     distance = sqrt(sum((diff / Sigma(:,:,k)) .* diff, 2));
%     scores(:,k) = scores(k) + weight * distance;
% end
% scores=  posterior(gmm,x1_2);
% [mm,nn]=find(min(mean(scores(1:m3,:))));
% RTscore_test=scores(1:m1_2,nn);
% 
% ATscore_test=cat(1,RTscore_test,ATscore_test);
% [~,~,T11,AUCf_attack_gmm] = perfcurve(testLabel,ATscore_test,1);
% %%%%%%%%%%%%%%%vali_real
% clear scores
% scores = zeros(N,K);
% weights = gmm.ComponentProportion;
% for k = 1:K
%     weight=weights(:,k);
%     diff = bsxfun(@minus, x2, mu(k,:));
%     distance= sqrt(sum((diff / Sigma(:,:,k)) .* diff, 2));
%     scores(:,k) = scores(k) + weight * distance;
% end
% 
% [mm,nn]=find(min(mean(scores(1:m3,:))));
% RTscore_vali=scores(1:m3,nn);
% %%%%%%%%%%%%%%vali_fakem
% clear scores
% scores = zeros(N,K);
% weights = gmm.ComponentProportion;
% for k = 1:K
%     weight=weights(:,k);
%     diff = bsxfun(@minus, x3, mu(k,:));
%     distance = sqrt(sum((diff / Sigma(:,:,k)) .* diff, 2));
%     scores(:,k) = scores(k) + weight * distance;
% end
% 
% [mm,nn]=find(min(mean(scores(1:m3,:))));
% ATscore_vali=scores(1:m4,nn);
% % 
% % observations=x1_1;
% % % Calculate GMM scores for each observation
% % scores = zeros(size(observations, 1), 1);
% % 
% % for i = 1:size(observations, 1)
% %   observation = observations(i, :);
% %   for j = 1:3
% %     mean = means(j, :);
% %     covariance = covariances(:, :, j);
% %     weight = weights(j);
% % 
% %     % Calculate Mahalanobis distance
% %     diff = bsxfun(@minus, x1_1, mu(j,:));
% %     distance = sqrt(sum((diff / Sigma(:,:,j)) .* diff, 2));
% %     %distance = mahal(observation, mean, covariance);
% %     scores(i) = scores(i) + weight * distance;
% %   end
% % end
% % 
% % 
% 
% 
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\GMM\RTscores\train\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'RTscore_train');
% 
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\GMM\RTscores\vali\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'RTscore_vali');
% 
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\GMM\ATscores\vali\', file_name);
% save(strcat(fullFileName_attack,'.mat'),'ATscore_vali');
% 
% fullFileName_attack = fullfile('E:\scores\',Faces,'\',R,'\',Network,'\GMM\ATscores\test\', file_name);
%save(strcat(fullFileName_attack,'.mat'),'ATscore_test');
% %%%%%GMM_ENDS
end
count=count+1;
end
end
end