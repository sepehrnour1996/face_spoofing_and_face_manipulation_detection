n=10000;
c=3;
P=10;
R=10000;
d=10;
S=abs(zscore(abs(rand(c,n))));
  
A=[eye(n,c);S';-S'];
M=ones(n,1);
y=M;
b=[zeros(n,1);zeros(n,1);-M];
W_new=abs(rand(c,1));
lambda=abs(rand(3*n,1));
for i=1:1000000
    W=W_new;
    W_new=pinv(2*S*S')*(2*S*y+A'*lambda-d*P*W.^(P-1));
    lambda=lambda-0.001*(A*W-b);
    if abs(W-W_new)<=0.0001
        break
    end
   if max(S'*W_new)==1
    if norm(W_new,P)^P<=1 
        if min(W_new)>=0 
            if min(S'*W_new)>=0

                     break
            end
        end
    end 
end
end
% % Z=abs(rand(c,1));
% % u=abs(rand(c,1));
% % W_new=pinv(2*S*S'+R*eye(c,c))*(A'*lambda+R*(Z-u)+2*S*y);
% % lambda_new=pinv(2*A*pinv(R*eye(c,c)'+2*S*S')*S*S'*pinv(R*eye(c,c)+2*S*S')*A'+2*R*A*pinv(R*eye(c,c)'+2*S*S')*pinv(R*eye(c,c)+2*S*S')*A'-A*pinv(R*eye(c,c)+2*S*S')*A'-A*pinv(R*eye(c,c)'+2*S*S')*A')*(-2*A*pinv(R*eye(c,c)'+2*S*S')*S*S'*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))+2*A*pinv(R*eye(c,c)'+2*S*S')*S*y-2*R*A*pinv(R*eye(c,c)'+2*S*S')*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))-2*R*A*pinv(R*eye(c,c)'+2*S*S')*(u-Z)+A*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))+b);
% % lambda=lambda_new;
% for j=1:1000
% W=W_new;
% lambda_new=pinv(2*A*pinv(R*eye(c,c)'+2*S*S')*S*S'*pinv(R*eye(c,c)+2*S*S')*A'+2*R*A*pinv(R*eye(c,c)'+2*S*S')*pinv(R*eye(c,c)+2*S*S')*A'-A*pinv(R*eye(c,c)+2*S*S')*A'-A*pinv(R*eye(c,c)'+2*S*S')*A')*(-2*A*pinv(R*eye(c,c)'+2*S*S')*S*S'*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))+2*A*pinv(R*eye(c,c)'+2*S*S')*S*y-2*R*A*pinv(R*eye(c,c)'+2*S*S')*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))-2*R*A*pinv(R*eye(c,c)'+2*S*S')*(u-Z)+A*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))+b);
% lambda=lambda_new;
% W_new=pinv(2*S*S'+R*eye(c,c))*(A'*lambda+R*(Z-u)+2*S*y);
% if abs(W_new-W)<=0.0001
%     break
% end
% lambda_new=pinv(2*A*pinv(R*eye(c,c)'+2*S*S')*S*S'*pinv(R*eye(c,c)+2*S*S')*A'+2*R*A*pinv(R*eye(c,c)'+2*S*S')*pinv(R*eye(c,c)+2*S*S')*A'-A*pinv(R*eye(c,c)+2*S*S')*A'-A*pinv(R*eye(c,c)'+2*S*S')*A')*(-2*A*pinv(R*eye(c,c)'+2*S*S')*S*S'*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))+2*A*pinv(R*eye(c,c)'+2*S*S')*S*y-2*R*A*pinv(R*eye(c,c)'+2*S*S')*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))-2*R*A*pinv(R*eye(c,c)'+2*S*S')*(Z-u)+A*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))+b);
% lambda=lambda_new;
% W_new=pinv(2*S*S'+R*eye(c,c))*(A'*lambda+R*(Z-u)+2*S*y);
% W=W_new;
% Z_new=pinv((R^(3))*pinv(R*eye(c,c)'+2*S*S')*pinv(R*eye(c,c)+2*S*S')-(R^(2))*pinv(R*eye(c,c)'+2*S*S')-(R^(2))*pinv(R*eye(c,c)+2*S*S')+R*eye(c,c))*(-d*P*Z.^(P-1)-(R^(2))*pinv(R*eye(c,c)'+2*S*S')*(u+pinv(R*eye(c,c)+2*S*S')*(A'*lambda+2*S*y-R*u))+R*(u+pinv(R*eye(c,c)+2*S*S')*(A'*lambda+2*S*y-R*u)));
% 
% for j=1
% Z=Z_new;
% Z_new=pinv((R^(3))*pinv(R*eye(c,c)'+2*S*S')*pinv(R*eye(c,c)+2*S*S')-(R^(2))*pinv(R*eye(c,c)'+2*S*S')-(R^(2))*pinv(R*eye(c,c)+2*S*S')+R*eye(c,c))*(-d*P*Z.^(P-1)-(R^(2))*pinv(R*eye(c,c)'+2*S*S')*(u+pinv(R*eye(c,c)+2*S*S')*(A'*lambda+2*S*y-R*u))+R*(u+pinv(R*eye(c,c)+2*S*S')*(A'*lambda+2*S*y-R*u)));
% end
% 
% u=u+W_new-Z_new;
% end

%lambda=pinv(2*A*pinv(R*eye(c,c)'+2*S*S')*S*S'*pinv(R*eye(c,c)+2*S*S')*A'+2*R*A*pinv(R*eye(c,c)'+2*S*S')*oinv(R*eye(c,c)+2*S*S')*A'-A*pinv(R*eye(c,c)+2*S*S')*A'-A*pinv(R*eye(c,c)'+2*S*S')*A')*(-2*A*pinv(R*eye(c,c)'+2*S*S')*S*S'*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))+2*A*pinv(R*eye(c,c)'+2*S*S')*S*y-2*R*A*pinv(R*eye(c,c)'+2*S*S')*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))-2*R*A*pinv(R*eye(c,c)'+2*S*S')*(u-Z)+A*pinv(R*eye(c,c)+2*S*S')*(2*S*y+R*(Z-u))+b);
