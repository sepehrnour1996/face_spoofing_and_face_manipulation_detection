coeff=.25;
G = EuDist2(x_train,x_train,0);
D = sum(sum(triu(G,1)));
Md1 = coeff*D/(size(G,1)-1)/(size(G,1)-2);
K1 = exp(-1*G./Md1);
K=reshape(1/12*sum(K1,1),size(K1,2),size(K1,3));


clear kz14
G = EuDist2(x_train,x_test,0);
kz14= exp(-1*G./Md1);
Ks= reshape(1/12*sum(kz14,1),size(kz14,2),size(kz14,3));

G = EuDist2(x_test,1,0);
kz15= exp(-1*G./Md1);
Kss = reshape(1/12*sum(kz15,1),size(kz15,2),size(kz15,3));
modes={'mean','var','pred','ratio'};
titles={'mean \mu_*','neg. variance -\sigma^2_*','log. predictive probability p(y=1|X,y,x_*)','log. moment ratio \mu_*/\sigma_*'};
noise=0.01;
K=K1+noise*eye(size(K1));Kss=Kss+noise*ones(size(Kss));
L = chol(K)';
alpha = L'\(L\ones(size(K,1),1));
Y = kz14' * alpha; 

for i=1:4
score=GPR_OCC(K1,kz14,Kss,modes{i});
score222{i}=score;
end