%clear
clear K1
clear Ktest
clear Ktest2
clear Ktest1
Faceforensics={'NeuralTextures'};
Model={'alexnet','darknet19','inceptionv3'};
region={'R1','R2','R3'};
count=1;
ML_models={'KPCA','SVDD','GPR','GMM'}

for jj=1:1000
    c=36;
    clear w
    clear RTscore_region
    clear ATscore_region
    clear RTscore11
    clear ATscore11
    clear RTscore_total_net
    clear RTscore_vali_total_net
    clear ATscore_total_net
    clear ATscore_vali_total_net
    clear RTscore_total_region
    clear RTscore_total_region_vali
    clear ATscore_total_region
    clear ATscore_total_region_vali
    clear RTscore_total
    clear ATscore_total
    clear RTscore_total_net_V
    clear RTscore_vali_total_net_V
    clear ATscore_total_net_V
    clear ATscore_vali_total_net_V
    clear RTscore_total_region_V
    clear RTscore_total_region_vali_V
    clear ATscore_total_region_V
    clear ATscore_total_region_vali_V
    clear RTscore_total_V
    clear ATscore_total_V
    Faces=Faceforensics{1,f};
    for r=1:3
     R=region{1,r}; 
    
    for net=1:3
            Network=Model{1,net};
    
            matfiles_real = (dir(fullfile('/media/bilkent/Seagate Expansion Drive/c40/original/freq',R,'/',Network,'/Real/*.mat'))); 
            matfiles_fake = (dir(fullfile('/media/bilkent/Seagate Expansion Drive/c40/',Faces,'/freq/',R,'/',Network,'/',Faces,'/*.mat'))) ;
            N = length(matfiles_real) 
            path =fullfile('/media/bilkent/Seagate Expansion Drive/c40/original/freq/',R,'/',Network,'/Real/');
            path1 =fullfile('/media/bilkent/Seagate Expansion Drive/c40/',Faces,'/freq/',R,'/',Network,'/',Faces,'/');
            %%%googlenet KPCA       
            data_real=cell(N,1);
            data_fake=cell(N,1);
            clear K1
            clear Ktest
            clear Ktest2
            clear Ktest1
            if f==2||3||4   
                file=matfiles_real(jj).name;
                currentfile=[path,file]; 
                file1=matfiles_fake(jj).name;
                fname=file1(5:7);
                d=str2num(file1(5:7));
                file1=matfiles_fake(d+1).name;
                currentfile1=[path1,file1];
                S = load(currentfile1);
                S1 = load(currentfile);
            
            else
                file1=matfiles_fake(jj).name;
                currentfile1=[path1,file1];   
                file=matfiles_real(jj).name;
                currentfile=[path,file]; 
                S = load(currentfile1);
                S1 = load(currentfile);
            end
            data=cell2mat(struct2cell(S1))';
            data1=cell2mat(struct2cell(S))';
            %%%%%NORMALIZING DATA
            x_real=normr(data);
            x_fake=normr(data1);
            [m_real,n_real]=size(x_real);
            [m_fake,n_fake]=size(x_fake);
            
            %%%%%Splitting
            
            m_train=round(m_real*0.72);
            m_train_fake=round(m_fake*0.72);
            m_vali_test_real=round(m_real*0.14);
            m_vali_test_fake=round(m_fake*0.14);
            
            x_train=(x_real(1:m_train,:));
            x_vali_real=x_real(m_train+1:m_train+m_vali_test_real,:);
            x_test_real=x_real(m_train+m_vali_test_real+1:m_real,:);
            
            x_vali_fake=x_fake(m_train_fake+1:m_train_fake+m_vali_test_fake,:);
            x_test_fake=x_fake(m_train_fake+m_vali_test_fake+1:m_fake,:);
            
            x_vali=[x_vali_real;x_vali_fake];
            x_test=[x_test_real;x_test_fake];
            %%%%%KPCA
            clear K1
            clear G
            coeff=0.25;
            G = EuDist2(x_train,x_train,0);
            D = sum(sum(triu(G,1)));
            Md1 = coeff*D/(size(G,1)-1)/(size(G,1)-2);
            K1= exp(-1*G./Md1);
            T=reshape(1/12*sum(K1,1),size(K1,2),size(K1,3));
            clear kz14
            clear G
            G = EuDist2(x_train,x_vali_real,0);
            kz14 = exp(-1*G./Md1);
            Ktest = reshape(1/12*sum(kz14,1),size(kz14,2),size(kz14,3));
            clear kz141
            clear G
            G = EuDist2(x_train,x_vali_fake,0);
            kz141= exp(-1*G./Md1);
            Ktest2 = reshape(1/12*sum(kz141,1),size(kz141,2),size(kz141,3));
            clear kz12
            clear G
            G = EuDist2(x_train,x_test,0);
            kz12= exp(-1*G./Md1);
            Ktest1 = reshape(1/12*sum(kz12,1),size(kz12,2),size(kz12,3));
            % % 
    
            
            k=kk(1,indexOfMaxY);
            selected_k(:,jj+net+r)=k;
            kernel = Kernel('type', 'gaussian', 'gamma', 0.25);
            parameter = struct('numComponents', k, ...
                               'kernelFunc', kernel);               
    
            kpca = KernelPCA(parameter);
            % train KPCA model
            kpca.train(x_train);
            clear results1
            % test KPCA model
            results1 = kpca.test(x_train);
            RTscore_train_KPCA=2/size(results1.temporary.Kt,2)*sum(results1.temporary.Kt,1)'-sum((results1.score).^2,2);%sum(results.score,2);%
            results = kpca.test(x_vali_real);
    
            RTscore_vali_KPCA=2/size(results1.temporary.Kt,2)*sum(results.temporary.Kt',1)'-sum(results.score.^2,2);%-2/size(K1,2)*sum(kz14,1)'-sum((projected_Xvali_real.^2),2);
            results = kpca.test(x_vali_fake);
    
            ATscore_vali_KPCA=2/size(results1.temporary.Kt,2)*sum(results.temporary.Kt',1)'-sum((results.score).^2,2);
            results = kpca.test(x_test);
            ATscore_test_KPCA1=2/size(results1.temporary.Kt,2)*sum(results.temporary.Kt',1)'-sum((results.score).^2,2);%-2/size(K1,2)*sum(kz12,1)'-sum((projected_Xtest.^2),2)
            file_name = [num2str(jj)]
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/KPCA/RTscores/train/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_train_KPCA');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/KPCA/RTscores/vali/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_vali_KPCA');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/KPCA/ATscores/vali/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_vali_KPCA');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/KPCA/ATscores/test/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_test_KPCA1');
            % % %%%%%KPCA
            % % %%%%%SVDD_STARTS
            [m1,n1]=size(x_train);
            [m2,n2]=size(x_test_real);
            [m3,n3]=size(x_test_fake);
            [m4,n4]=size(x_vali_real);
            [m5,n5]=size(x_vali_fake);
            
            trainLabel=ones(m1,1);
            valiLabel=ones(m4,1);
            valiLabel2=-1*ones(m5,1);
            valiLabel0=[valiLabel;valiLabel2];
            testLabel=[ones(m2,1);zeros(m3,1)];
            
            threshold_kpca=(median(RTscore_vali_KPCA)+median(ATscore_vali_KPCA))/2;
            PREDICTED_LABELS=ATscore_test_KPCA1>threshold_kpca;
            CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel);
            ACC_KPCA=CORRECT_PREDICTION/numel(testLabel);
            
            [~,~,T11,AUCf_attack_kpca] = perfcurve(testLabel,ATscore_test_KPCA1,1);
             %%%%%%%%%%%%%%%%%
            results = kpca.test(x_test_real);
            RTscore_test_KPCA=2/size(results1.temporary.Kt,2)*sum(results.temporary.Kt',1)'-sum((results.score).^2,2);%-2/size(K1,2)*sum(kz12,1)'-sum((projected_Xtest.^2),2)
            
            
            results = kpca.test(x_test_fake);
            %projected_Xtest = project(kpca, x_test, M
            ATscore_test_KPCA=2/size(results1.temporary.Kt,2)*sum(results.temporary.Kt',1)'-sum((results.score).^2,2);%-2/size(K1,2)*sum(kz12,1)'-sum((projected_Xtest.^2),2)
           
    
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/KPCA/RTscores/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_test_KPCA');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/KPCA/ATscores/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_test_KPCA');
            RTscore=RTscore_test_KPCA;
            ATscore=ATscore_test_KPCA;
            scores=[RTscore(:)' ATscore(:)'];
            T=sort(scores,'descend');
            Tp=[T(1) T(1:end-1)];
            T=.5*(T+Tp);
            mi=0.01;
            for ii=1:length(T)
                for t=T(:,ii)
                e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
                e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
                Thresholdf=t;
                EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
            
                end
            end
            [min_diff,min_index]=min(abs(e1-e2));
            
            EER_KPCA=EERf(min_index);
    %%%%%%%%%%%%%%%%%%%%%%
            cost = [0.1 1 10 100];
            gamma=[0.01 0.1 1 10];
            for c1=1:size(cost,2)
                for g=1:size(gamma,2)
                    c11=cost(1,c1);
                    g11=gamma(1,g);
                    kernel = BaseKernel('type', 'gaussian', 'gamma', g11);
                    svddParameter = struct('cost', c11, 'kernelFunc', kernel);
                    svdd = BaseSVDD(svddParameter);
                    % train SVDD model
                    svdd.train(x_train, trainLabel);
                    results_vali = svdd.test(x_vali, valiLabel0);
                    accuracy(g,1)=results_vali.performance.AUC;
                    gg(g,1)=g11;
                    cc(c1,1)=c11;
        
                end
                accuracy_c(:,c1)=accuracy;
            end
            [maximum,index] = max(accuracy_c);
           gamma1=gamma(1,index(1,1));
           [maximum,index1] = max(max(accuracy_c));
           cost1=cost(1,index1);
           selected_gamma(jj+net+r,1)=gamma1;
           selected_cost(jj+net+r,1)=cost1;
    
            kernel = BaseKernel('type', 'gaussian', 'gamma', gamma1);
            svddParameter = struct('cost', cost1, 'kernelFunc', kernel);
            svdd = BaseSVDD(svddParameter);
            % train SVDD model
            svdd.train(x_train, trainLabel);
            % test SVDD model
            testLabel1=[ones(m2,1);-ones(m3,1)];
            results_train = svdd.test(x_train, trainLabel);
            results_vali = svdd.test(x_vali_real, valiLabel);
            results_vali2 = svdd.test(x_vali_fake, valiLabel2);
            results_test = svdd.test(x_test, testLabel1);
            
            
            % compute the distance between each test sample and the center
            
            RTscores=results_train.radius-results_train.distance;
            RTscore_train_SVDD=RTscores;
            RTscore_train_SVDD_V=median(RTscore_train_SVDD);
            
            RTscores=results_train.radius-results_vali.distance;
            RTscore_vali_SVDD=RTscores;
            RTscore_vali_SVDD_V=median(RTscore_vali_SVDD);
            
            ATscores=results_train.radius-results_vali2.distance;
            ATscore_vali_SVDD=ATscores;
            ATscore_vali_SVDD_V=median(ATscore_vali_SVDD);
            
            
            ATscores=results_train.radius-results_test.distance;
            ATscore_test_SVDD1=ATscores;
            
            
            threshold_svdd=(median(RTscore_vali_SVDD)+median(ATscore_vali_SVDD))/2;
            PREDICTED_LABELS=ATscore_test_SVDD1>threshold_svdd;
            CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel);
            ACC_SVDD=CORRECT_PREDICTION/numel(testLabel);
            
            [~,~,T11,AUCf_attack_svdd] = perfcurve(testLabel,ATscore_test_SVDD1,1);
            %%%%%%%%%%%%%%%%%%%%%%%
            results_test_real = svdd.test(x_test_real, ones(size(x_test_real,1),1));
            results_test_fake = svdd.test(x_test_fake, -ones(size(x_test_fake,1),1));
            RTscore_test_SVDD=results_train.radius-results_test_real.distance;
            ATscore_test_SVDD=results_train.radius-results_test_fake.distance;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/SVDD/RTscores/train/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_train_SVDD');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/SVDD/RTscores/vali/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_vali_SVDD');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/SVDD/ATscores/vali/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_vali_SVDD');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/SVDD/ATscores/test/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_test_SVDD1');
    
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/SVDD/RTscores/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_test_SVDD');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/SVDD/ATscores/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_test_SVDD');
            RTscore=RTscore_test_SVDD;
            ATscore=ATscore_test_SVDD;
    
            scores=[RTscore(:)' ATscore(:)'];   
            T=sort(scores,'descend');
            Tp=[T(1) T(1:end-1)];
            T=.5*(T+Tp);
            mi=0.01;
            for ii=1:length(T)
                for t=T(:,ii)
                    e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
                    e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
                    Thresholdf=t;
                    EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
                end
            end
            [~,min_index]=min(abs(e1-e2));
            EER_SVDD=EERf(min_index);
    
            % %%%%SVDD_ENDS
            k=2;
            coeff=0.5;
            clear K1
            clear G
            G = EuDist2(x_train,x_train,0);
            D = sum(sum(triu(G,1)));
            Md1 = coeff*D/(size(G,1)-1)/(size(G,1)-2);
            K1= exp(-1*G./Md1);
            T=reshape(1/12*sum(K1,1),size(K1,2),size(K1,3));
            clear kz14
            clear G
            G = EuDist2(x_train,x_vali_real,0);
            kz14 = exp(-1*G./Md1);
            Ktest = reshape(1/12*sum(kz14,1),size(kz14,2),size(kz14,3));
            clear kz141
            clear G
            G = EuDist2(x_train,x_vali_fake,0);
            kz141= exp(-1*G./Md1);
            Ktest2 = reshape(1/12*sum(kz141,1),size(kz141,2),size(kz141,3));
            clear kz12
            clear G
            G = EuDist2(x_train,x_test,0);
            kz12= exp(-1*G./Md1);
            Ktest1 = reshape(1/12*sum(kz12,1),size(kz12,2),size(kz12,3));
            clear kz15
            G = EuDist2(x_train,1,0);
            kz15= exp(-1*G./Md1);
            Kss = reshape(1/12*sum(kz15,1),size(kz15,2),size(kz15,3));
            clear kz15
            G = EuDist2(x_test,1,0);
            kz15= exp(-1*G./Md1);
            Kss1 = reshape(1/12*sum(kz15,1),size(kz15,2),size(kz15,3));
            clear kz15
            G = EuDist2(x_vali_fake,1,0);
            kz15= exp(-1*G./Md1);
            Kss2 = reshape(1/12*sum(kz15,1),size(kz15,2),size(kz15,3));
            clear kz15
            G = EuDist2(x_vali_real,1,0);
            kz15= exp(-1*G./Md1);
            Kss3 = reshape(1/12*sum(kz15,1),size(kz15,2),size(kz15,3));
            
            modes={'mean','var','pred','ratio'};
            titles={'mean \mu_*','neg. variance -\sigma^2_*','log. predictive probability p(y=1|X,y,x_*)','log. moment ratio \mu_*/\sigma_*'};
            score=GPR_OCC(K1,K1,Kss,modes{1});
            RTscore_train_GPR=score;
            
            score=GPR_OCC(K1,kz12,Kss1,modes{1});
            ATscore_test_GPR1=score;
            
            score=GPR_OCC(K1,kz141,Kss2,modes{1});
            ATscore_vali_GPR=score;
            
            score=GPR_OCC(K1,kz14,Kss3,modes{1});
            RTscore_vali_GPR=score;
            %%%%%%%%%%%%%%%%
            clear kz13
            clear G
            G = EuDist2(x_train,x_test_real,0);
            kz13= exp(-1*G./Md1);
            RTscore_test_GPR=GPR_OCC(K1,kz13,Kss1,modes{1});
            
            clear kz131
            clear G
            G = EuDist2(x_train,x_test_fake,0);
            kz131= exp(-1*G./Md1);
            ATscore_test_GPR=GPR_OCC(K1,kz131,Kss1,modes{1});
      
            threshold_gpr=(median(RTscore_vali_GPR)+median(ATscore_vali_GPR))/2;
            PREDICTED_LABELS=ATscore_test_GPR1>threshold_gpr;
            CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel);
            ACC_GPR=CORRECT_PREDICTION/numel(testLabel);
            
            [~,~,T11,AUCf_attack_gpr] = perfcurve(testLabel,ATscore_test_GPR1,1);
            RTscore=RTscore_test_GPR;
            ATscore=ATscore_test_GPR;
            scores=[RTscore(:)' ATscore(:)'];
            T=sort(scores,'descend');
            Tp=[T(1) T(1:end-1)];
            T=.5*(T+Tp);
            mi=0.01;
            for ii=1:length(T)
                for t=T(:,ii)
                    e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
                    e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
                    Thresholdf=t;
                    EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
            
                end
            end
            [min_diff,min_index]=min(abs(e1-e2)); 
            EER_GPR=EERf(min_index);
                    fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GPR/RTscores/train/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_train_GPR');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GPR/RTscores/vali/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_vali_GPR');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GPR/ATscores/vali/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_vali_GPR');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GPR/ATscores/test/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_test_GPR1');
    
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GPR/RTscores/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_test_GPR');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GPR/ATscores/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_test_GPR');
    %%%%%%%%%%%%%%%%%%%%GMM
            clear x2
            clear x1
            clear selected_x
            clear AUC23
            
            if size(x_train,1)>=size(x_train,2)
                X = x_train(:,1:1000); % input data
                x1_1=x_test_fake(:,1:1000);
                x1_2=x_test_real(:,1:1000);
                x1_1_vali=x_vali_fake(:,1:1000);
                x1_2_vali=x_vali_real(:,1:1000);
            else
                X = x_train(:,1:size(x_train,1)-1); % input data
                x1_1=x_test_fake(:,1:size(x_train,1)-1);
                x1_2=x_test_real(:,1:size(x_train,1)-1);
                x1_1_vali=x_vali_fake(:,1:size(x_train,1)-1);
                x1_2_vali=x_vali_real(:,1:size(x_train,1)-1);
            end
            
            
            gmm=fitgmdist(X,3,'RegularizationValue',.1);
            Sigma=gmm.Sigma+eps;
            
            clear scores
            scores = zeros(size(X,1),1);
            weights = gmm.ComponentProportion;
            for i=1:size(X,1)
              
                for k = 1:3  
                    diff = bsxfun(@minus, (X(i,:)), gmm.mu(k,:));
                    distance(1,k)= sqrt(sum((diff/ gmm.Sigma(:,:,k)) .* diff, 2));
                end
            
                [~,assignment] = (min(distance));
                likelihood = weights(assignment)*mvnpdf(X(i,:),gmm.mu(assignment,:),Sigma(:,:,assignment));
                scores(i,1) = scores(i,1)+ log(likelihood);
            end
            
            clear newscorestrain
            for i=1:size(X,1)
                t=scores(i,1);
                if t==inf
                    t=max(scores(~isinf(scores)));
                    newscorestrain(i,1)=t;
                else
                    newscorestrain(i,1)=t;
                end
                
            end
            RTscore_train_GMM=newscorestrain;
            
            clear scores1
            clear newscores
            scores1 = zeros(size(x1_2_vali,1),1);
            weights = gmm.ComponentProportion;
             for i=1:size(x1_2_vali,1)
                for k =1:3
                    diff = bsxfun(@minus, (x1_2_vali(i,:)), gmm.mu(k,:));
                    distance(1,k)= sqrt(sum((diff/ gmm.Sigma(:,:,k)) .* diff, 2));
                end
                
                [~,assignment] = (min(distance));
                likelihood = weights(assignment)*mvnpdf(x1_2_vali(i,:),gmm.mu(assignment,:),Sigma(:,:,assignment));
                
                scores1(i,1) = scores1(i,1)+ log(likelihood);
            end
            clear newscoresvali
            for i=1:size(x1_2_vali,1)
                t=scores1(i,1);
                if t==inf
                    t=max(scores1(~isinf(scores1)));
                    newscoresvali(i,1)=t;
                else
                    newscoresvali(i,1)=t;
                end
                
            end
            
            RTscore_vali_GMM=newscoresvali;
            
            clear scores_vali
            scores_vali = zeros(size(x1_1_vali,1),1);
            
            weights = gmm.ComponentProportion;
            for i=1:size(x1_1_vali,1)
                for k = 1:3
                    diff = bsxfun(@minus, (x1_1_vali(i,:)), gmm.mu(k,:));
                    distance(1,k)= sqrt(sum((diff/ gmm.Sigma(:,:,k)) .* diff, 2));
                end
                    
                [~,assignment] = (min(distance));
                likelihood = weights(assignment)*mvnpdf(x1_1_vali(i,:),gmm.mu(assignment,:),Sigma(:,:,assignment));
                
                scores_vali(i,1) = scores_vali(i,1)+ log(likelihood);
            end
            clear newscores_vali
            for i=1:size(x1_1_vali,1)
                t1=scores_vali(i,1);
                if t==inf
                    t1=max(scores_vali(~isinf(scores_vali)));
                    newscores_vali(i,1)=t1;
                   
                else
                    newscores_vali(i,1)=t1;
                end
                
            end
            
            ATscore_vali_GMM=newscores_vali;
            
            clear scores1
            scores1 = zeros(size(x1_2,1),1);
            weights = gmm.ComponentProportion;
            for i=1:size(x1_2,1)
                for k = 1:3
                    
                    diff = bsxfun(@minus, (x1_2(i,:)), gmm.mu(k,:));
                    distance(1,k)= sqrt(sum((diff/ gmm.Sigma(:,:,k)) .* diff, 2));
                end
            
                [~,assignment] = (min(distance));
                likelihood = weights(assignment)*mvnpdf(x1_2(i,:),gmm.mu(assignment,:),Sigma(:,:,assignment));
                
                scores1(i,:)= scores1(i,:)+log(likelihood);
            end
            clear newscores
            for i=1:size(x1_2,1)
                t=scores1(i,1);
                if t==inf
                    t=max(scores1(~isinf(scores1)));
                    newscores(i,1)=t;
                else
                    newscores(i,1)=t;
                end
                
            end
            
            RTscore_test_GMM=newscores;
            
            clear scores
            scores = zeros(size(x1_1,1),1);
            
            weights = gmm.ComponentProportion;
            for i=1:size(x1_1,1)
                for k = 1:3
                    
                    diff = bsxfun(@minus, (x1_1(i,:)), gmm.mu(k,:));
                    distance(1,k)= sqrt(sum((diff/ gmm.Sigma(:,:,k)) .* diff, 2));
                end
            
                [~,assignment] = (min(distance));
                likelihood = weights(assignment)*mvnpdf(x1_1(i,:),gmm.mu(assignment,:),Sigma(:,:,assignment));
                
                scores(i,1) = scores(i,1)+ log(likelihood);
            end
            clear newscores1
            for i=1:size(x1_1,1)
                t1=scores(i,1);
                if t==inf
                    t1=max(scores(~isinf(scores)));
                    newscores1(i,1)=t1;
                else
                    newscores1(i,1)=t1;
                end
                
            end
            ATscore_test_GMM=newscores1;
            ATscore_test_GMM1=cat(1,RTscore_test_GMM,ATscore_test_GMM);
            threshold_gmm=(median(RTscore_vali_GMM)+median(ATscore_vali_GMM))/2;
            PREDICTED_LABELS=ATscore_test_GMM1>threshold_gmm;
            CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel);
            ACC_GMM=CORRECT_PREDICTION/numel(testLabel);
            [~,~,T11,AUCf_attack_gmm] = perfcurve(testLabel,ATscore_test_GMM1,1);
            RTscore=RTscore_test_GMM;
            ATscore=ATscore_test_GMM;
            scores=[RTscore(:)' ATscore(:)'];
            T=sort(scores,'descend');
            Tp=[T(1) T(1:end-1)];
            T=.5*(T+Tp);
            mi=0.01;
            for ii=1:length(T)
                for t=T(:,ii)
                    e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
                    e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
                    Thresholdf=t;
                    EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
            
                end
            end
            [~,min_index]=min(abs(e1-e2));
            EER_GMM=EERf(min_index);
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GMM/RTscores/train/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_train_GMM');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GMM/RTscores/vali/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_vali_GMM');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GMM/ATscores/vali/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_vali_GMM');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GMM/ATscores/test/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_test_GMM1');
    
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GMM/RTscores/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'RTscore_test_GMM');
            
            fullFileName_attack = fullfile('/media/bilkent/Seagate Expansion Drive/scores_lq/',Faces,'/',R,'/',Network,'/GMM/ATscores/', file_name);
            save(strcat(fullFileName_attack,'.mat'),'ATscore_test_GMM');
             AUC_models=[AUCf_attack_kpca,AUCf_attack_svdd,AUCf_attack_gpr,AUCf_attack_gmm];
            ACC_models=[ACC_KPCA,ACC_SVDD,ACC_GPR,ACC_GMM];
            EER_models=[EER_KPCA,EER_SVDD,EER_GPR,EER_GMM];
            AUC_net(:,:,net)=AUC_models;
            ACC_net(:,:,net)=ACC_models;
            EER_net(:,:,net)=EER_models;
    
            RTscore_total=[RTscore_train_KPCA,RTscore_train_SVDD,RTscore_train_GPR,RTscore_train_GMM];
            ATscore_test_total=[ATscore_test_KPCA1,ATscore_test_SVDD1,ATscore_test_GPR1,ATscore_test_GMM1];
            RTscore_total_net(:,:,net)=[RTscore_train_KPCA,RTscore_train_SVDD,RTscore_train_GPR,RTscore_train_GMM];
            RTscore_vali_total_net(:,:,net)=[RTscore_vali_KPCA,RTscore_vali_SVDD,RTscore_vali_GPR,RTscore_vali_GMM];
            ATscore_vali_total_net(:,:,net)=[ATscore_vali_KPCA,ATscore_vali_SVDD,ATscore_vali_GPR,ATscore_vali_GMM];
            ATscore_total_net(:,:,net)=[ATscore_test_KPCA1,ATscore_test_SVDD1,ATscore_test_GPR1,ATscore_test_GMM1];
            RTscore11(:,:,net)=[RTscore_test_KPCA,RTscore_test_SVDD,RTscore_test_GPR,RTscore_test_GMM];
            ATscore11(:,:,net)=[ATscore_test_KPCA,ATscore_test_SVDD,ATscore_test_GPR,ATscore_test_GMM];
        
    end
    
        AUC_region(:,:,:,r)=AUC_net;
        ACC_region(:,:,:,r)=ACC_net;
        EER_region(:,:,:,r)=EER_net;
        R1=cat(2,RTscore_total_net(:,:,1),RTscore_total_net(:,:,2));
        R2=cat(2,R1,RTscore_total_net(:,:,3));
        R1_vali=cat(2,RTscore_vali_total_net(:,:,1),RTscore_vali_total_net(:,:,2));
        R2_vali=cat(2,R1_vali,RTscore_vali_total_net(:,:,3));
        A1_vali=cat(2,ATscore_vali_total_net(:,:,1),ATscore_vali_total_net(:,:,2));
        A2_vali=cat(2,A1_vali,ATscore_vali_total_net(:,:,3));
        A1=cat(2,ATscore_total_net(:,:,1),ATscore_total_net(:,:,2));
        A2=cat(2,A1,ATscore_total_net(:,:,3));
        RTscore_total_region(:,:,:,r)=RTscore_total_net;
        RTscore_total_region_vali(:,:,:,r)=RTscore_vali_total_net;
        ATscore_total_region_vali(:,:,:,r)=ATscore_vali_total_net;
        ATscore_total_region(:,:,:,r)=ATscore_total_net;
        RTscore_region(:,:,:,r)=RTscore11;
        ATscore_region(:,:,:,r)=ATscore11;
    
    end
    AUC_video(:,:,:,:,jj)=AUC_region;
    ACC_video(:,:,:,:,jj)=ACC_region;
    EER_video(:,:,:,:,jj)=EER_region;
    R1_region=cat(2,RTscore_total_region(:,:,:,1),RTscore_total_region(:,:,:,2));
    R2_region=cat(2,R1_region,RTscore_total_region(:,:,:,3));
    R1_net=cat(2,R2_region(:,:,1),R2_region(:,:,2));
    R2_net=cat(2,R1_net,R2_region(:,:,3));
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
    R1_region_vali=cat(2,RTscore_total_region_vali(:,:,:,1),RTscore_total_region_vali(:,:,:,2));
    R2_region_vali=cat(2,R1_region_vali,RTscore_total_region_vali(:,:,:,3));
    R1_net_vali=cat(2,R2_region_vali(:,:,1),R2_region_vali(:,:,2));
    R2_net_vali=cat(2,R1_net_vali,R2_region_vali(:,:,3));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    A1_region_vali=cat(2,ATscore_total_region_vali(:,:,:,1),ATscore_total_region_vali(:,:,:,2));
    A2_region_vali=cat(2,A1_region_vali,ATscore_total_region_vali(:,:,:,3));
    A1_net_vali=cat(2,A2_region_vali(:,:,1),A2_region_vali(:,:,2));
    A2_net_vali=cat(2,A1_net_vali,A2_region_vali(:,:,3));
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
    A1_region=cat(2,ATscore_total_region(:,:,:,1),ATscore_total_region(:,:,:,2));
    A2_region=cat(2,A1_region,ATscore_total_region(:,:,:,3));
    A1_net=cat(2,A2_region(:,:,1),A2_region(:,:,2));
    A2_net=cat(2,A1_net,A2_region(:,:,3));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    R1_region=cat(2,RTscore_region(:,:,:,1),RTscore_region(:,:,:,2));
    R2_region=cat(2,R1_region,RTscore_region(:,:,:,3));
    R1_net=cat(2,R2_region(:,:,1),R2_region(:,:,2));
    R2_net2=cat(2,R1_net,R2_region(:,:,3));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    A1_region=cat(2,ATscore_region(:,:,:,1),ATscore_region(:,:,:,2));
    A2_region=cat(2,A1_region,ATscore_region(:,:,:,3));
    A1_net=cat(2,A2_region(:,:,1),A2_region(:,:,2));
    A2_net2=cat(2,A1_net,A2_region(:,:,3));
    
    
    
    RTscore_total=R2_net;
    ATscore_vali_final=cat(1,R2_net_vali,A2_net_vali);
    label_vali=[ones(size(R2_net_vali,1),1);zeros(size(A2_net_vali,1),1)];
    ATscore_test_total=A2_net;
    [m11,n11]=size(RTscore_total);
    
    mu=mean((RTscore_total(:)));
    sigma=std((RTscore_total(:)));
    
    [~,mu,sig]=zscore(RTscore_total);
    
    RR=0.5*((RTscore_total-mu)./(3*sig)+1);
    
    RZ0_new_vali=0.5*((R2_net_vali-mu)./(3*sig)+1);
    AZ0_new_vali=0.5*((A2_net_vali-mu)./(3*sig)+1);
    RZ01_new=0.5*((R2_net2-mu)./(3*sig)+1);
    AZ01_new=0.5*((A2_net2-mu)./(3*sig)+1);
    Z0_new=[RZ01_new;AZ01_new];
    %%%%%%%%%%%%%%%%%%%%Video base%%%%%%%%%%%%%%%%%%
    RZ0_new_train_v1=median(RR);
    RZ0_new_train_v2=min(RR);
    RZ0_new_train_v3=max(RR);
    RZ0_new_train_v4=mean(RR);
    RZ0_new_train_v5=prod(RR);
    RZ0_new_train_v6=[RZ0_new_train_v1;RZ0_new_train_v2;RZ0_new_train_v3;RZ0_new_train_v4;RZ0_new_train_v5];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    RZ0_new_vali_v1=median(RZ0_new_vali);
    RZ0_new_vali_v2=min(RZ0_new_vali);
    RZ0_new_vali_v3=max(RZ0_new_vali);
    RZ0_new_vali_v4=mean(RZ0_new_vali);
    RZ0_new_vali_v5=prod(RZ0_new_vali);
    RZ0_new_vali_v6=[RZ0_new_vali_v1;RZ0_new_vali_v2;RZ0_new_vali_v3;RZ0_new_vali_v4;RZ0_new_vali_v5];
    %%%%%%%%%%%
    AZ0_new_vali_v1=median(AZ0_new_vali);
    AZ0_new_vali_v2=min(AZ0_new_vali);
    AZ0_new_vali_v3=max(AZ0_new_vali);
    AZ0_new_vali_v4=mean(AZ0_new_vali);
    AZ0_new_vali_v5=prod(AZ0_new_vali);
    AZ0_new_vali_v6=[AZ0_new_vali_v1;AZ0_new_vali_v2;AZ0_new_vali_v3;AZ0_new_vali_v4;AZ0_new_vali_v5];
    %%%%%%%%%%%
    Z01_new_v1=median(RZ01_new);
    Z01_new_v2=min(RZ01_new);
    Z01_new_v3=max(RZ01_new);
    Z01_new_v4=mean(RZ01_new);
    Z01_new_v5=prod(RZ01_new);
    Z01_new_v6=[Z01_new_v1;Z01_new_v2;Z01_new_v3;Z01_new_v4;Z01_new_v5];
    %%%%%%%%%%%%%%%%%%%%%%%%
    Z02_new_v1=median(AZ01_new);
    Z02_new_v2=min(AZ01_new);
    Z02_new_v3=max(AZ01_new);
    Z02_new_v4=mean(AZ01_new);
    Z02_new_v5=prod(AZ01_new);
    Z02_new_v6=[Z02_new_v1;Z02_new_v2;Z02_new_v3;Z02_new_v4;Z02_new_v5];
    Z0_new_v6=cat(2,Z01_new_v6,Z02_new_v6);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    R_train=0.5*(1+tanh(0.001*(RTscore_total-mu.*ones(size(RTscore_total,1),c))./sig.*ones(size(RTscore_total,1),c)));%
    RZ1_new_vali= 0.5*(1+tanh(0.001*(R2_net_vali-mu.*ones(size(R2_net_vali,1),c))./sig.*ones(size(R2_net_vali,1),c)));%(R2_net_vali-mu)./sig;
    AZ1_new_vali=0.5*(1+tanh(0.001*(A2_net_vali-mu.*ones(size(A2_net_vali,1),c))./sig.*ones(size(A2_net_vali,1),c)));%(A2_net_vali-mu)./sig;
    RZ1_new= 0.5*(1+tanh(0.001*(R2_net2-mu.*ones(size(R2_net2,1),c))./sig.*ones(size(R2_net2,1),c)));%(R2_net_vali-mu)./sig;
    AZ1_new=0.5*(1+tanh(0.001*(A2_net2-mu.*ones(size(A2_net2,1),c))./sig.*ones(size(A2_net2,1),c)));%(A2_net_vali-mu)./sig;
    Z1_new=[RZ1_new;AZ1_new];%0.5*(1+tanh(0.01*(ATscore_test_total-mu.*ones(size(ATscore_test_total,1),c))./sig.*ones(size(ATscore_test_total,1),c)));
    %%%%%%%%%%%%%%%%%%%%Video base%%%%%%%%%%%%%%%%%%
    RZ1_new_train_v1=median(R_train);
    RZ1_new_train_v2=min(R_train);
    RZ1_new_train_v3=max(R_train);
    RZ1_new_train_v4=mean(R_train);
    RZ1_new_train_v5=prod(R_train);
    RZ1_new_train_v6=[RZ1_new_train_v1;RZ1_new_train_v2;RZ1_new_train_v3;RZ1_new_train_v4;RZ1_new_train_v5];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    RZ1_new_vali_v1=median(RZ1_new_vali);
    RZ1_new_vali_v2=min(RZ1_new_vali);
    RZ1_new_vali_v3=max(RZ1_new_vali);
    RZ1_new_vali_v4=mean(RZ1_new_vali);
    RZ1_new_vali_v5=prod(RZ1_new_vali);
    RZ1_new_vali_v6=[RZ1_new_vali_v1;RZ1_new_vali_v2;RZ1_new_vali_v3;RZ1_new_vali_v4;RZ1_new_vali_v5];
    %%%%%%%%%%%
    AZ1_new_vali_v1=median(AZ1_new_vali);
    AZ1_new_vali_v2=min(AZ1_new_vali);
    AZ1_new_vali_v3=max(AZ1_new_vali);
    AZ1_new_vali_v4=mean(AZ1_new_vali);
    AZ1_new_vali_v5=prod(AZ1_new_vali);
    AZ1_new_vali_v6=[AZ1_new_vali_v1;AZ1_new_vali_v2;AZ1_new_vali_v3;AZ1_new_vali_v4;AZ1_new_vali_v5];
    %%%%%%%%%%%
    Z11_new_v1=median(RZ1_new);
    Z11_new_v2=min(RZ1_new);
    Z11_new_v3=max(RZ1_new);
    Z11_new_v4=mean(RZ1_new);
    Z11_new_v5=prod(RZ1_new);
    Z11_new_v6=[Z11_new_v1;Z11_new_v2;Z11_new_v3;Z11_new_v4;Z11_new_v5];
    %%%%%%%%%%%%%%%%%%%%%%%%
    Z12_new_v1=median(AZ1_new);
    Z12_new_v2=min(AZ1_new);
    Z12_new_v3=max(AZ1_new);
    Z12_new_v4=mean(AZ1_new);
    Z12_new_v5=prod(AZ1_new);
    Z12_new_v6=[Z12_new_v1;Z12_new_v2;Z12_new_v3;Z12_new_v4;Z12_new_v5];
    Z1_new_v6=cat(2,Z11_new_v6,Z12_new_v6);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    minn=prctile(RTscore_total,5);
    maxx=prctile(RTscore_total,95);
    minmaxtrain1=(RTscore_total-minn)./((maxx-minn));
    minmaxtest1=(ATscore_test_total-minn)./((maxx-minn));
    Rminmaxtest_vali=(R2_net_vali-minn)./((maxx-minn));
    Aminmaxtest_vali=(A2_net_vali-minn)./((maxx-minn));
    
    Rminmaxtest=(R2_net2-minn)./((maxx-minn));
    Aminmaxtest=(A2_net2-minn)./((maxx-minn));
    minmaxtest1=[Rminmaxtest;Aminmaxtest];
    %%%%%%%%%%%%%%%%%%%%Video base%%%%%%%%%%%%%%%%%%
    Rminmaxtest_train_v1=median(minmaxtrain1);
    Rminmaxtest_train_v2=min(minmaxtrain1);
    Rminmaxtest_train_v3=max(minmaxtrain1);
    Rminmaxtest_train_v4=mean(minmaxtrain1);
    Rminmaxtest_train_v5=prod(minmaxtrain1);
    Rminmaxtest_train_v6=[Rminmaxtest_train_v1;Rminmaxtest_train_v2;Rminmaxtest_train_v3;Rminmaxtest_train_v4;Rminmaxtest_train_v5];
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Rminmaxtest_vali_v1=median(Rminmaxtest_vali);
    Rminmaxtest_vali_v2=min(Rminmaxtest_vali);
    Rminmaxtest_vali_v3=max(Rminmaxtest_vali);
    Rminmaxtest_vali_v4=mean(Rminmaxtest_vali);
    Rminmaxtest_vali_v5=prod(Rminmaxtest_vali);
    Rminmaxtest_vali_v6=[Rminmaxtest_vali_v1;Rminmaxtest_vali_v2;Rminmaxtest_vali_v3;Rminmaxtest_vali_v4;Rminmaxtest_vali_v5];
    %%%%%%%%%%%
    Aminmaxtest_vali_v1=median(Aminmaxtest_vali);
    Aminmaxtest_vali_v2=min(Aminmaxtest_vali);
    Aminmaxtest_vali_v3=max(Aminmaxtest_vali);
    Aminmaxtest_vali_v4=mean(Aminmaxtest_vali);
    Aminmaxtest_vali_v5=prod(Aminmaxtest_vali);
    Aminmaxtest_vali_v6=[Aminmaxtest_vali_v1;Aminmaxtest_vali_v2;Aminmaxtest_vali_v3;Aminmaxtest_vali_v4;Aminmaxtest_vali_v5];
    %%%%%%%%%%%
    minmaxtest1_v1=median(Rminmaxtest);
    minmaxtest1_v2=min(Rminmaxtest);
    minmaxtest1_v3=max(Rminmaxtest);
    minmaxtest1_v4=mean(Rminmaxtest);
    minmaxtest1_v5=prod(Rminmaxtest);
    minmaxtest1_v6=[minmaxtest1_v1;minmaxtest1_v2;minmaxtest1_v3;minmaxtest1_v4;minmaxtest1_v5];
    %%%%%%%%%%%%%%%%%%%%%%%%
    minmaxtest2_v1=median(Aminmaxtest);
    minmaxtest2_v2=min(Aminmaxtest);
    minmaxtest2_v3=max(Aminmaxtest);
    minmaxtest2_v4=mean(Aminmaxtest);
    minmaxtest2_v5=prod(Aminmaxtest);
    minmaxtest2_v6=[minmaxtest2_v1;minmaxtest2_v2;minmaxtest2_v3;minmaxtest2_v4;minmaxtest2_v5];
    minmaxtest_v6=cat(2,minmaxtest1_v6,minmaxtest2_v6);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    med1=median(RTscore_total);
    mad_x = median(abs(RTscore_total - med1.*ones(size(RTscore_total,1),c)));
    RmodifiedZ1_train=(RTscore_total-med1.*ones(size(RTscore_total,1),c))./mad_x;
    %%%%%%%%%%%%%%
    mad_x = median(abs(R2_net_vali - med1.*ones(size(R2_net_vali,1),c)));
    RmodifiedZ1=(R2_net_vali-med1.*ones(size(R2_net_vali,1),c))./mad_x;
    %med1=median(A2_net_vali);
    mad_x = median(abs(A2_net_vali - med1.*ones(size(A2_net_vali,1),c)));
    AmodifiedZ1=(A2_net_vali-med1.*ones(size(A2_net_vali,1),c))./mad_x;
    %med1=median(R2_net2);
    mad_x = median(abs(R2_net2 - med1.*ones(size(R2_net2,1),c)));
    RmodifiedZ12=(R2_net2-med1.*ones(size(R2_net2,1),c))./mad_x;
    %med1=median(A2_net2);
    mad_x = median(abs(A2_net2 - med1.*ones(size(A2_net2,1),c)));
    AmodifiedZ12=(A2_net2-med1.*ones(size(A2_net2,1),c))./mad_x;
    %med1=median(ATscore_test_total);
    mad_x = median(abs(ATscore_test_total - med1.*ones(size(ATscore_test_total,1),c)));
    modifiedZ1=(ATscore_test_total-med1.*ones(size(ATscore_test_total,1),c))./mad_x;
    %%%%%%%%%%%%%%%%%%%%Video base%%%%%%%%%%%%%%%%%%
    RmodifiedZ1_train_v1=median(RmodifiedZ1_train);
    RmodifiedZ1_train_v2=min(RmodifiedZ1_train);
    RmodifiedZ1_train_v3=max(RmodifiedZ1_train);
    RmodifiedZ1_train_v4=mean(RmodifiedZ1_train);
    RmodifiedZ1_train_v5=prod(RmodifiedZ1_train);
    RmodifiedZ1_train_v6=[RmodifiedZ1_train_v1;RmodifiedZ1_train_v2;RmodifiedZ1_train_v3;RmodifiedZ1_train_v4;RmodifiedZ1_train_v5];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    RmodifiedZ1_v1=median(RmodifiedZ1);
    RmodifiedZ1_v2=min(RmodifiedZ1);
    RmodifiedZ1_v3=max(RmodifiedZ1);
    RmodifiedZ1_v4=mean(RmodifiedZ1);
    RmodifiedZ1_v5=prod(RmodifiedZ1);
    RmodifiedZ1_v6=[RmodifiedZ1_v1;RmodifiedZ1_v2;RmodifiedZ1_v3;RmodifiedZ1_v4;RmodifiedZ1_v5];
    %%%%%%%%%%%
    AmodifiedZ1_v1=median(AmodifiedZ1);
    AmodifiedZ1_v2=min(AmodifiedZ1);
    AmodifiedZ1_v3=max(AmodifiedZ1);
    AmodifiedZ1_v4=mean(AmodifiedZ1);
    AmodifiedZ1_v5=prod(AmodifiedZ1);
    AmodifiedZ1_v6=[AmodifiedZ1_v1;AmodifiedZ1_v2;AmodifiedZ1_v3;AmodifiedZ1_v4;AmodifiedZ1_v5];
    %%%%%%%%%%%
    modifiedZ11_v1=median(RmodifiedZ12);
    modifiedZ11_v2=min(RmodifiedZ12);
    modifiedZ11_v3=max(RmodifiedZ12);
    modifiedZ11_v4=mean(RmodifiedZ12);
    modifiedZ11_v5=prod(RmodifiedZ12);
    modifiedZ11_v6=[modifiedZ11_v1;modifiedZ11_v2;modifiedZ11_v3;modifiedZ11_v4;modifiedZ11_v5];
    %%%%%%%%%%%
    modifiedZ12_v1=median(AmodifiedZ12);
    modifiedZ12_v2=min(AmodifiedZ12);
    modifiedZ12_v3=max(AmodifiedZ12);
    modifiedZ12_v4=mean(AmodifiedZ12);
    modifiedZ12_v5=prod(AmodifiedZ12);
    modifiedZ12_v6=[modifiedZ12_v1;modifiedZ12_v2;modifiedZ12_v3;modifiedZ12_v4;modifiedZ12_v5];
    modifiedZ1_v6=cat(2,modifiedZ11_v6,modifiedZ12_v6);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    p1=[32/31,16/15,8/7,4/3,2,4,100];
    c2=[10^(-5),10^(-4),10^(-3),10^(-2),10^(-1),1,100];
    validation=[RZ0_new_vali;AZ0_new_vali];
    labelvalidation=[ones(size(RZ0_new_vali,1),1);zeros(size(AZ0_new_vali,1),1)];
    S=RR;
    [n,m]=size(S);
    for pp=1:7
        for cc=1:7
            p=p1(1,pp);
            c1=c2(1,cc);
            cvx_begin 
                variables w(c,1)
                %minimize 1/n*sum((ones(n,1)-S*w).^2)+c1*sum(pow_abs(w,p))
                minimize 1/n*sum(max(zeros(n,1),ones(n,1)-S*w))+c1*sum(pow_abs(w,p))
            cvx_end
            cvx_clear
    % 
            ATscores0_noCVX=validation*w;
            [~,~,T11,AUCf] = perfcurve(labelvalidation,ATscores0_noCVX,1);
            AUCF_cc_zscore(1,cc)=AUCf;
        end
        AUCF_pp_zscore(pp,:)=AUCF_cc_zscore;
    end
    AUCF_sample_zscore=AUCF_pp_zscore;
    matrix2=AUCF_sample_zscore;
    [row col]=find(ismember(matrix2, max(matrix2(:))));
    p=p1(1,row);
    p11=p(1,1);
    c1=c2(1,col);
    c21=c1(1,1);
    cvx_begin 
        variables w(c,1)
        %minimize 1/n*sum((ones(n,1)-S*w).^2)+c21*sum(pow_abs(w,p11))
        minimize 1/n*sum(max(zeros(n,1),ones(n,1)-S*w))+c21*sum(pow_abs(w,p11))
    cvx_end
    cvx_clear
    %w1=ones(c,1);
    ATscores0_noCVX=(Z0_new)*w;
    [~,~,T11,AUCf_attack_noncvx_zscore01] = perfcurve(testLabel,ATscores0_noCVX,1);
    % %%%%%%%%%%%%%%%%%%%%%%%
    RTscore=ATscores0_noCVX(1:size(RTscore_test_GMM,1),:);
    ATscore=ATscores0_noCVX(size(RTscore_test_GMM,1)+1:size(ATscores0_noCVX,1),:);
    scores=[RTscore(:)' ATscore(:)'];
    T=sort(scores,'descend');
    Tp=[T(1) T(1:end-1)];
    T=.5*(T+Tp);
    mi=0.01;
    for ii=1:length(T)
        for t=T(:,ii)
        e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
        e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
        Thresholdf=t;
        EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
        end
    end
    [min_diff,min_index]=min(abs(e1-e2));
    
    EER_zscore01=EERf(min_index);
    %%%%%%%%%%%%%%%%%%%%%%%
    threshold_NOCVX=(median(RZ0_new_vali*w)+median(AZ0_new_vali*w))./2;
    PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
    CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel);
    ACC_ZSCORE01=CORRECT_PREDICTION/numel(testLabel);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%videobase%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    count=0;
    for l=1:4
        RZ0_new_train1=RZ0_new_train_v6(l,:);
        RZ0_new_vali1=RZ0_new_vali_v6(l,:);
        AZ0_new_vali1=AZ0_new_vali_v6(l,:);
        Z0_new1=Z0_new_v6(l,:);
        Z0_new=[Z0_new1(1,1:36);Z0_new1(1,37:72)];
        testLabel1=[1;0];
        validation=[RZ0_new_vali1;AZ0_new_vali1];
        labelvalidation=[ones(size(RZ0_new_vali1,1),1);zeros(size(AZ0_new_vali1,1),1)];
        S=RZ0_new_train1;
        ATscores0_noCVX=(Z0_new)*w;
        [~,~,T11,AUCf_attack_noncvx_zscore0] = perfcurve(testLabel1,ATscores0_noCVX,1);
        % %%%%%%%%%%%%%%%%%%%%%%%
        RTscore=ATscores0_noCVX(1,:);
        ATscore=ATscores0_noCVX(2,:);
        scores=[RTscore(:)' ATscore(:)'];
        T=sort(scores,'descend');
        Tp=[T(1) T(1:end-1)];
        T=.5*(T+Tp);
        mi=0.01;
        for ii=1:length(T)
            for t=T(:,ii)
            e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
            e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
            Thresholdf=t;
            EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
            end
        end
        [min_diff,min_index]=min(abs(e1-e2));
        
        EER_zscore0=EERf(min_index);
        %%%%%%%%%%%%%%%%%%%%%%%
        if l==2||l==3
        scores1=[(RZ0_new_vali*w)' (AZ0_new_vali*w)'];
        T1=sort(scores1,'ascend');
        ACC_MIN_MAX=[];
        for u=1:size(scores1,2)
            threshold_NOCVX=T1(1,u);
            PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
            CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
            ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
            T2(u,1)=threshold_NOCVX;
            ACC_MIN_MAX(u,1)=(ACC_ZSCORE0);
        end
         [max_diff,max_index]=max(ACC_MIN_MAX);
        threshold_NOCVX=T2(max_index,1);
        PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
        CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
        ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
        end
        if l==1||l==4||l==5
        threshold_NOCVX=(median(RZ0_new_vali*w)+median(AZ0_new_vali*w))./2;
        PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
        CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
        ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
        end
        AUC_ZSCORE_VIDEO(l,:)=AUCf_attack_noncvx_zscore0;
        ACC_ZSCORE_VIDEO(l,:)=ACC_ZSCORE0;
        EER_ZSCORE_VIDEO(l,:)=EER_zscore0;
        count=count+1;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
    validation=[RZ1_new_vali;AZ1_new_vali];
    labelvalidation=[ones(size(RZ1_new_vali,1),1);zeros(size(AZ1_new_vali,1),1)];
    S=R_train;
    [n,m]=size(S);
    
    ATscores1_noCVX=(Z1_new)*w;
    [~,~,T11,AUCf_attack_noncvx_zscore] = perfcurve(testLabel,ATscores1_noCVX,1);
    % %%%%%%%%%%%%%%%%%%%%%%%
    RTscore=ATscores1_noCVX(1:size(RTscore_test_GMM,1),:);
    ATscore=ATscores1_noCVX(size(RTscore_test_GMM,1)+1:size(ATscores1_noCVX,1),:);
    scores=[RTscore(:)' ATscore(:)'];
    T=sort(scores,'descend');
    Tp=[T(1) T(1:end-1)];
    T=.5*(T+Tp);
    mi=0.01;
    for ii=1:length(T)
        for t=T(:,ii)
        e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
        e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
        Thresholdf=t;
        EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
    
        end
    end
    [min_diff,min_index]=min(abs(e1-e2));
    
    EER_zscore=EERf(min_index);
    %%%%%%%%%%%%%%%%%%%%%%%
    threshold_NOCVX=(median(RZ1_new_vali*w)+median(AZ1_new_vali*w))./2;
    PREDICTED_LABELS=ATscores1_noCVX>=threshold_NOCVX;
    CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel);
    ACC_ZSCORE=CORRECT_PREDICTION/numel(testLabel);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%videobase%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for l=1:4
        RZ0_new_vali1=RZ1_new_vali_v6(l,:);
        AZ0_new_vali1=AZ1_new_vali_v6(l,:);
        RZ0_new_train1=RZ1_new_train_v6(l,:);
        Z0_new1=Z1_new_v6(l,:);
        Z0_new=[Z0_new1(1,1:36);Z0_new1(1,37:72)];
        testLabel1=[1;0];
        validation=[RZ0_new_vali1;AZ0_new_vali1];
        labelvalidation=[ones(size(RZ0_new_vali1,1),1);zeros(size(AZ0_new_vali1,1),1)];
        ATscores0_noCVX=(Z0_new)*w;
        [~,~,T11,AUCf_attack_noncvx_zscore0] = perfcurve(testLabel1,ATscores0_noCVX,1);
        % %%%%%%%%%%%%%%%%%%%%%%%
        RTscore=ATscores0_noCVX(1,:);
        ATscore=ATscores0_noCVX(2,:);
        scores=[RTscore(:)' ATscore(:)'];
        T=sort(scores,'descend');
        Tp=[T(1) T(1:end-1)];
        T=.5*(T+Tp);
        mi=0.01;
        for ii=1:length(T)
            for t=T(:,ii)
            e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
            e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
            Thresholdf=t;
            EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
            end
        end
        [min_diff,min_index]=min(abs(e1-e2));
        
        EER_zscore0=EERf(min_index);
        %%%%%%%%%%%%%%%%%%%%%%%
        if l==2||l==3
        scores1=[(RZ1_new_vali*w)' (AZ1_new_vali*w)'];
        T1=sort(scores1,'ascend');
        ACC_MIN_MAX=[];
        for u=1:size(scores1,2)
            threshold_NOCVX=T1(1,u);
            PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
            CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
            ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
            T2(u,1)=threshold_NOCVX;
            ACC_MIN_MAX(u,1)=(ACC_ZSCORE0);
        end
         [max_diff,max_index]=max(ACC_MIN_MAX);
        threshold_NOCVX=T2(max_index,1);%(min(RZ0_new_vali*w1)+min(AZ0_new_vali*w1))./2;
        PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
        CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
        ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
        end
        if l==1||l==4||l==5
        threshold_NOCVX=(median(RZ1_new_vali*w)+median(AZ1_new_vali*w))/2;
        PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
        CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
        ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
        end
        AUC_TANH_VIDEO(l,:)=AUCf_attack_noncvx_zscore0;
        ACC_TANH_VIDEO(l,:)=ACC_ZSCORE0;
        EER_TANH_VIDEO(l,:)=EER_zscore0;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
    validation=[RmodifiedZ1;AmodifiedZ1];
    labelvalidation=[ones(size(RmodifiedZ1,1),1);zeros(size(AmodifiedZ1,1),1)];
    S=RmodifiedZ1_train;
    [n,m]=size(S);
    ATscores1_noCVX_modified=(modifiedZ1)*w;
    [~,~,T11,AUCf_attack_noncvx_modified] = perfcurve(testLabel,ATscores1_noCVX_modified,1);
    
    % %%%%%%%%%%%%%%%%%%%%%%%
    RTscore=ATscores1_noCVX_modified(1:size(RTscore_test_GMM,1),:);
    ATscore=ATscores1_noCVX_modified(size(RTscore_test_GMM,1)+1:size(ATscores1_noCVX_modified,1),:);
    scores=[RTscore(:)' ATscore(:)'];
    T=sort(scores,'descend');
    Tp=[T(1) T(1:end-1)];
    T=.5*(T+Tp);
    mi=0.01;
    for ii=1:length(T)
        for t=T(:,ii)
        e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
        e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
        Thresholdf=t;
        EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
    
        end
    end
    [min_diff,min_index]=min(abs(e1-e2));
    EER_modified_zscore=EERf(min_index);
    
    %%%%%%%%%%%%%%%%%%%%%%%
    threshold_NOCVX=(median(RmodifiedZ1*w)+median(AmodifiedZ1*w))/2;
    PREDICTED_LABELS=ATscores1_noCVX_modified>=threshold_NOCVX;
    CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel);
    ACC_modifiedzscore=CORRECT_PREDICTION/numel(testLabel);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%videobase%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for l=1:4
        RZ0_new_train1=RmodifiedZ1_train_v6(l,:);
        RZ0_new_vali1=RmodifiedZ1_v6(l,:);
        AZ0_new_vali1=AmodifiedZ1_v6(l,:);
        Z0_new1=modifiedZ1_v6(l,:);
        Z0_new=[Z0_new1(1,1:36);Z0_new1(1,37:72)];
        testLabel1=[1;0];
        validation=[RZ0_new_vali1;AZ0_new_vali1];
        labelvalidation=[ones(size(RZ0_new_vali1,1),1);zeros(size(AZ0_new_vali1,1),1)];
        ATscores0_noCVX=(Z0_new)*w;
        [~,~,T11,AUCf_attack_noncvx_zscore0] = perfcurve(testLabel1,ATscores0_noCVX,1);
        % %%%%%%%%%%%%%%%%%%%%%%%
        RTscore=ATscores0_noCVX(1,:);
        ATscore=ATscores0_noCVX(2,:);
        scores=[RTscore(:)' ATscore(:)'];
        T=sort(scores,'descend');
        Tp=[T(1) T(1:end-1)];
        T=.5*(T+Tp);
        mi=0.01;
        for ii=1:length(T)
            for t=T(:,ii)
            e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
            e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
            Thresholdf=t;
            EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
            end
        end
        [min_diff,min_index]=min(abs(e1-e2));
        
        EER_zscore0=EERf(min_index);
        count1=0;
        %%%%%%%%%%%%%%%%%%%%%%%
        if l==2||l==3
        scores1=[(RmodifiedZ1*w)' (AmodifiedZ1*w)'];
        T1=sort(scores1,'ascend');
        ACC_MIN_MAX=[];
        for u=1:size(scores1,2)
            threshold_NOCVX=T1(1,u);
            PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
            CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
            ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
            T2(u,1)=threshold_NOCVX;
            ACC_MIN_MAX(u,1)=(ACC_ZSCORE0);
        end
         [max_diff,max_index]=max(ACC_MIN_MAX);
        threshold_NOCVX=T2(max_index,1);%(min(RZ0_new_vali*w1)+min(AZ0_new_vali*w1))./2;
        PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
        CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
        ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
        count1=count1+1;
        end
        if l==1||l==4||l==5
        threshold_NOCVX=(median(RmodifiedZ1*w)+median(AmodifiedZ1*w))./2;
        PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
        CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
        ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
        end
        AUC_MODIFIEDZSCORE_VIDEO(l,:)=AUCf_attack_noncvx_zscore0;
        ACC_MODIFIEDZSCORE_VIDEO(l,:)=ACC_ZSCORE0;
        EER_MODIFIEDZSCORE_VIDEO(l,:)=EER_zscore0;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
    validation=[Rminmaxtest_vali;Aminmaxtest_vali];
    labelvalidation=[ones(size(Rminmaxtest_vali,1),1);zeros(size(Aminmaxtest_vali,1),1)];
    S=minmaxtrain1;
    [n,m]=size(S);
    
    ATscores1_noCVX_minmaxtest=(minmaxtest1)*w;
    [~,~,T11,AUCf_attack_noncvx_zscore_minmax] = perfcurve(testLabel,ATscores1_noCVX_minmaxtest,1);
    %%%%%%%%%%%%%%%%%%%%%%%
    RTscore=ATscores1_noCVX_minmaxtest(1:size(RTscore_test_GMM,1),:);
    ATscore=ATscores1_noCVX_minmaxtest(size(RTscore_test_GMM,1)+1:size(ATscores1_noCVX_minmaxtest,1),:);
    scores=[RTscore(:)' ATscore(:)'];
    T=sort(scores,'descend');
    Tp=[T(1) T(1:end-1)];
    T=.5*(T+Tp);
    mi=0.01;
    for ii=1:length(T)
        for t=T(:,ii)
        e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
        e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
        Thresholdf=t;
        EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
        end
    end
    [min_diff,min_index]=min(abs(e1-e2));
    EER_minmax=EERf(min_index);
    
    %%%%%%%%%%%%%%%%%%%%%%%
    threshold_NOCVX=(median(Rminmaxtest_vali*w)+median(Aminmaxtest_vali*w))./2;
    PREDICTED_LABELS=ATscores1_noCVX_minmaxtest>=threshold_NOCVX;
    CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel);
    ACC_minmaxtest=CORRECT_PREDICTION/numel(testLabel);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%videobase%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for l=1:4
        RZ0_new_vali1=Rminmaxtest_vali_v6(l,:);
        AZ0_new_vali1=Aminmaxtest_vali_v6(l,:);
        Z0_new1=minmaxtest_v6(l,:);
        Z0_new=[Z0_new1(1,1:36);Z0_new1(1,37:72)];
        RZ0_new_train1=Rminmaxtest_train_v6(l,:);
        validation=[RZ0_new_vali1;AZ0_new_vali1];
        labelvalidation=[ones(size(RZ0_new_vali1,1),1);zeros(size(AZ0_new_vali1,1),1)];
        ATscores0_noCVX=(Z0_new)*w;
        [~,~,T11,AUCf_attack_noncvx_zscore0] = perfcurve(testLabel1,ATscores0_noCVX,1);
        % %%%%%%%%%%%%%%%%%%%%%%%
        RTscore=ATscores0_noCVX(1,:);
        ATscore=ATscores0_noCVX(2,:);
        scores=[RTscore(:)' ATscore(:)'];
        T=sort(scores,'descend');
        Tp=[T(1) T(1:end-1)];
        T=.5*(T+Tp);
        mi=0.01;
        for ii=1:length(T)
            for t=T(:,ii)
            e1(ii,:)=sum(RTscore<t)/size(RTscore,1);
            e2(ii,:)=sum(ATscore>=t)/size(ATscore,1);
            Thresholdf=t;
            EERf(ii,1)=.5*(e1(ii,:)+e2(ii,:));
            end
        end
        [min_diff,min_index]=min(abs(e1-e2));
        
        EER_zscore0=EERf(min_index);
        %%%%%%%%%%%%%%%%%%%%%%%
        if l==2||l==3
        scores1=[(Rminmaxtest_vali*w)' (Aminmaxtest_vali*w)'];
        T1=sort(scores1,'ascend');
        ACC_MIN_MAX=[];
        for u=1:size(scores1,2)
            threshold_NOCVX=T1(1,u);
            PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
            CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
            ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
            T2(u,1)=threshold_NOCVX;
            ACC_MIN_MAX(u,1)=(ACC_ZSCORE0);
        end
         [max_diff,max_index]=max(ACC_MIN_MAX);
        threshold_NOCVX=T2(max_index,1);%(min(RZ0_new_vali*w1)+min(AZ0_new_vali*w1))./2;
        PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
        CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
        ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
        end
        if l==1||l==4||l==5
        threshold_NOCVX=(median(Rminmaxtest_vali*w)+median(Aminmaxtest_vali*w))./2;
        PREDICTED_LABELS=ATscores0_noCVX>=threshold_NOCVX;
        CORRECT_PREDICTION=sum(PREDICTED_LABELS==testLabel1);
        ACC_ZSCORE0=CORRECT_PREDICTION/numel(testLabel1);
        end
        AUC_MINMAX_VIDEO(l,:)=AUCf_attack_noncvx_zscore0;
        ACC_MINMAX_VIDEO(l,:)=ACC_ZSCORE0;
        EER_MINMAX_VIDEO(l,:)=EER_zscore0;
    end
    %  AUCF_sample_minmax_v{jj}=AUCF_l_minmax_v;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
    AUC_NONCVX0(jj,1)=AUCf_attack_noncvx_zscore01;
    AUC_NONCVX1(jj,1)=AUCf_attack_noncvx_zscore;
    AUC_NONCVX2(jj,1)=AUCf_attack_noncvx_modified;
    AUC_NONCVX3(jj,1)=AUCf_attack_noncvx_zscore_minmax;
    % % 
    ACC_NONCVX0(jj,1)=ACC_ZSCORE01;
    ACC_NONCVX1(jj,1)=ACC_ZSCORE;
    ACC_NONCVX2(jj,1)=ACC_modifiedzscore;
    ACC_NONCVX3(jj,1)=ACC_minmaxtest;
    
    EER_NONCVX0(jj,1)=EER_zscore01;
    EER_NONCVX1(jj,1)=EER_zscore;
    EER_NONCVX2(jj,1)=EER_modified_zscore;
    EER_NONCVX3(jj,1)=EER_minmax;
    
    AUC_NONCVX0_V(jj,:)=AUC_ZSCORE_VIDEO';
    AUC_NONCVX1_V(jj,:)=AUC_TANH_VIDEO';
    AUC_NONCVX2_V(jj,:)=AUC_MODIFIEDZSCORE_VIDEO';
    AUC_NONCVX3_V(jj,:)=AUC_MINMAX_VIDEO';
    
    ACC_NONCVX0_V(jj,:)=ACC_ZSCORE_VIDEO';
    ACC_NONCVX1_V(jj,:)=ACC_TANH_VIDEO';
    ACC_NONCVX2_V(jj,:)=ACC_MODIFIEDZSCORE_VIDEO';
    ACC_NONCVX3_V(jj,:)=ACC_MINMAX_VIDEO';
    
    EER_NONCVX0_V(jj,:)=EER_ZSCORE_VIDEO';
    EER_NONCVX1_V(jj,:)=EER_TANH_VIDEO';
    EER_NONCVX2_V(jj,:)=EER_MODIFIEDZSCORE_VIDEO';
    EER_NONCVX3_V(jj,:)=EER_MINMAX_VIDEO';
    
    file_name = [num2str(jj)]
    
    end
    AUC_total_models=mean(AUC_video,5);
    count=1;
    for r=1:3
        R=region{1,r};  
    for net=1:3
        Network=Model{1,net};
    for ml=1:4
    
    ML=ML_models{1,ml};
    AA=AUC_total_models(:,ml,net,r);
    filename = ['AUC_22',Faces,'.xlsx'];
    rows={'A2','A3','A4','A5','A6','A7'};
    model=['_',ML,'_'];
    writematrix(model,filename,'Sheet',1,'Range',rows{ml});
    
    
    [~,~,T11,AUCf_attack] = perfcurve(testlabel,ATscore_ML_deepfake{ml},0);
    headlines_columns={'B1','C1','D1','E1','F1','G1','H1','I1','J1','K1','L1','M1','N1','O1','P1','Q1','R1','S1','T1','U1'};
    data_columns={'B2','C2','D2','E2','F2','G2','H2','I2','J2','K2','L2','M2','N2','O2','P2','Q2','R2','S2','T2','U2';'B3','C3','D3','E3','F3','G3','H3','I3','J3','K3','L3','M3','N3','O3','P3','Q3','R3','S3','T3','U3';'B4','C4','D4','E4','F4','G4','H4','I4','J4','K4','L4','M4','N4','O4','P4','Q4','R4','S4','T4','U4';'B5','C5','D5','E5','F5','G5','H5','I5','J5','K5','L5','M5','N5','O5','P5','Q5','R5','S5','T5','U5'};
    column_name=['AUC_',Faces,'_',R,'_',Network,'_'];
    writematrix(column_name,filename,'Sheet',1,'Range',headlines_columns{1,count+1});
    writematrix(double(AA),filename,'Sheet',1,'Range',data_columns{ml,count+1});
    end
    count=count+1;
    end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
    ACC_total_models=mean(ACC_video,5);
    count=1;
    for r=1:3
        R=region{1,r};  
    for net=1:3
        Network=Model{1,net};
    for ml=1:4
    
    ML=ML_models{1,ml};
    AA=ACC_total_models(:,ml,net,r);
    filename = ['ACC_22',Faces,'.xlsx'];
    rows={'A2','A3','A4','A5','A6','A7'};
    model=['_',ML,'_'];
    writematrix(model,filename,'Sheet',1,'Range',rows{ml});
    
    
    [~,~,T11,AUCf_attack] = perfcurve(testlabel,ATscore_ML_deepfake{ml},0);
    headlines_columns={'B1','C1','D1','E1','F1','G1','H1','I1','J1','K1','L1','M1','N1','O1','P1','Q1','R1','S1','T1','U1'};
    data_columns={'B2','C2','D2','E2','F2','G2','H2','I2','J2','K2','L2','M2','N2','O2','P2','Q2','R2','S2','T2','U2';'B3','C3','D3','E3','F3','G3','H3','I3','J3','K3','L3','M3','N3','O3','P3','Q3','R3','S3','T3','U3';'B4','C4','D4','E4','F4','G4','H4','I4','J4','K4','L4','M4','N4','O4','P4','Q4','R4','S4','T4','U4';'B5','C5','D5','E5','F5','G5','H5','I5','J5','K5','L5','M5','N5','O5','P5','Q5','R5','S5','T5','U5'};
    column_name=['ACC_',Faces,'_',R,'_',Network,'_'];
    writematrix(column_name,filename,'Sheet',1,'Range',headlines_columns{1,count+1});
    writematrix(double(AA),filename,'Sheet',1,'Range',data_columns{ml,count+1});
    end
    count=count+1;
    end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    EER_total_models=mean(EER_video,5);
    count=1;
    for r=1:3
            R=region{1,r};  
        for net=1:3
            Network=Model{1,net};
            for ml=1:4
            
                ML=ML_models{1,ml};
                AA=EER_total_models(:,ml,net,r);
                filename = ['EER_22',Faces,'.xlsx'];
                rows={'A2','A3','A4','A5','A6','A7'};
                model=['_',ML,'_'];
                writematrix(model,filename,'Sheet',1,'Range',rows{ml});
                
                
                [~,~,T11,AUCf_attack] = perfcurve(testlabel,ATscore_ML_deepfake{ml},0);
                headlines_columns={'B1','C1','D1','E1','F1','G1','H1','I1','J1','K1','L1','M1','N1','O1','P1','Q1','R1','S1','T1','U1'};
                data_columns={'B2','C2','D2','E2','F2','G2','H2','I2','J2','K2','L2','M2','N2','O2','P2','Q2','R2','S2','T2','U2';'B3','C3','D3','E3','F3','G3','H3','I3','J3','K3','L3','M3','N3','O3','P3','Q3','R3','S3','T3','U3';'B4','C4','D4','E4','F4','G4','H4','I4','J4','K4','L4','M4','N4','O4','P4','Q4','R4','S4','T4','U4';'B5','C5','D5','E5','F5','G5','H5','I5','J5','K5','L5','M5','N5','O5','P5','Q5','R5','S5','T5','U5'};
                column_name=['EER_',Faces,'_',R,'_',Network,'_'];
                writematrix(column_name,filename,'Sheet',1,'Range',headlines_columns{1,count+1});
                writematrix(double(AA),filename,'Sheet',1,'Range',data_columns{ml,count+1});
            end
            count=count+1;
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%
    totalAUC_NONCVX0=mean(AUC_NONCVX0);
    totalAUC_NONCVX1=mean(AUC_NONCVX1);
    totalAUC_NONCVX2=mean(AUC_NONCVX2);
    totalAUC_NONCVX3=mean(AUC_NONCVX3);
    
    totalAUC_NONCVX0_V=mean(AUC_NONCVX0_V,1);
    totalAUC_NONCVX1_V=mean(AUC_NONCVX1_V,1);
    totalAUC_NONCVX2_V=mean(AUC_NONCVX2_V,1);
    totalAUC_NONCVX3_V=mean(AUC_NONCVX3_V,1);
    TT11=mean(TT);
    filename = ['AUC',Faces,'.xlsx'];
    
    writematrix(double(totalAUC_NONCVX1),filename,'Sheet',1);
    writematrix(double(totalAUC_NONCVX2),filename,'Sheet',2);
    writematrix(double(totalAUC_NONCVX3),filename,'Sheet',3);
    writematrix(double(totalAUC_NONCVX0),filename,'Sheet',4);
    
    totalACC_NONCVX0=mean(ACC_NONCVX0);
    totalACC_NONCVX1=mean(ACC_NONCVX1);
    totalACC_NONCVX2=mean(ACC_NONCVX2);
    totalACC_NONCVX3=mean(ACC_NONCVX3);
    
    totalACC_NONCVX0_V=mean(ACC_NONCVX0_V,1);
    totalACC_NONCVX1_V=mean(ACC_NONCVX1_V,1);
    totalACC_NONCVX2_V=mean(ACC_NONCVX2_V,1);
    totalACC_NONCVX3_V=mean(ACC_NONCVX3_V,1);
    TT11=mean(TT);
    filename = ['ACC',Faces,'.xlsx'];
    writematrix(double(totalAUC_CVX),filename,'Sheet',1);
    writematrix(double(totalACC_NONCVX1),filename,'Sheet',1);
    writematrix(double(totalACC_NONCVX2),filename,'Sheet',2);
    writematrix(double(totalACC_NONCVX3),filename,'Sheet',3);
    writematrix(double(totalACC_NONCVX0),filename,'Sheet',4);
    
    totalEER_NONCVX0=mean(EER_NONCVX0);
    totalEER_NONCVX1=mean(EER_NONCVX1);
    totalEER_NONCVX2=mean(EER_NONCVX2);
    totalEER_NONCVX3=mean(EER_NONCVX3);
    
    totalEER_NONCVX0_V=mean(EER_NONCVX0_V,1);
    totalEER_NONCVX1_V=mean(EER_NONCVX1_V,1);
    totalEER_NONCVX2_V=mean(EER_NONCVX2_V,1);
    totalEER_NONCVX3_V=mean(EER_NONCVX3_V,1);
    TT11=mean(TT);
    filename = ['EER',Faces,'.xlsx'];
    
    writematrix(double(totalEER_NONCVX1),filename,'Sheet',1);
    writematrix(double(totalEER_NONCVX2),filename,'Sheet',2);
    writematrix(double(totalEER_NONCVX3),filename,'Sheet',3);
    writematrix(double(totalEER_NONCVX0),filename,'Sheet',4);
    filename = ['EER_video',Faces,'.xlsx'];
    
    writematrix(double(totalEER_NONCVX1_V),filename,'Sheet',1);
    writematrix(double(totalEER_NONCVX2_V),filename,'Sheet',2);
    writematrix(double(totalEER_NONCVX3_V),filename,'Sheet',3);
    writematrix(double(totalEER_NONCVX0_V),filename,'Sheet',4);
